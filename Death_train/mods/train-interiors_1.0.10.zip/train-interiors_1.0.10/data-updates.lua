-- Train Interiors data updates.

local default_repair_sounds = {
  {filename = "__core__/sound/manual-repair-advanced-1.ogg", volume = 1},
  {filename = "__core__/sound/manual-repair-advanced-2.ogg", volume = 1},
}

if not (data.raw.sound and data.raw.sound["the-cave-inventory-repair"]) then
  local utility = data.raw["utility-sounds"] and data.raw["utility-sounds"]["default"]
  local manual = utility and utility.default_manual_repair
  data:extend({
    {
      type = "sound",
      name = "the-cave-inventory-repair",
      category = "game-effect",
      aggregation = {
        max_count = 1,
        count_already_playing = true,
        remove = true,
      },
      variations = manual and manual.variations or default_repair_sounds,
    }
  })
end

local lamp_setting = settings.startup["the-cave-lamp-post"]
if (not lamp_setting or lamp_setting.value == "enabled")
  and data.raw.lamp
  and data.raw.lamp["small-lamp"]
  and data.raw.lamp["lamp-post"] then
  data.raw.lamp["small-lamp"].next_upgrade = "lamp-post"
end

-- data-updates.lua

-- 1. Создаём три разные сетки
local grid_small = {
  type = "equipment-grid",
  name = "train-interiors-grid-small",
  width = 4, height = 4,
  equipment_categories = {"armor", "vehicle"}
}
local grid_medium = {
  type = "equipment-grid",
  name = "train-interiors-grid-medium",
  width = 6, height = 4,
  equipment_categories = {"armor", "vehicle"}
}
local grid_large = {
  type = "equipment-grid",
  name = "train-interiors-grid-large",
  width = 8, height = 6,
  equipment_categories = {"armor", "vehicle"}
}
data:extend({grid_small, grid_medium, grid_large})

-- 2. Функция для создания варианта локомотива
local function make_locomotive_variant(base_name, new_name, grid_name)
  local base = data.raw["locomotive"][base_name]
  if not base then return end
  local variant = table.deepcopy(base)
  variant.name = new_name
  variant.equipment_grid = grid_name
  -- При необходимости добавьте другие изменения (например, localised_name)
  data:extend({variant})
end

-- 3. Создаём три варианта на основе bob-locomotive-3
make_locomotive_variant("bob-locomotive-3", "train-interiors-loco-small", "train-interiors-grid-small")
make_locomotive_variant("bob-locomotive-3", "train-interiors-loco-medium", "train-interiors-grid-medium")
make_locomotive_variant("bob-locomotive-3", "train-interiors-loco-large", "train-interiors-grid-large")