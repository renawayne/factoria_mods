-- Train Interiors rolling stock is exploration-only. Apply this after every
-- dependency so no later technology can restore one of the vanilla recipe
-- unlocks. Railway and Artillery keep all of their non-wagon effects.
local blocked_train_recipes = {
  ["locomotive"] = true,
  ["cargo-wagon"] = true,
  ["fluid-wagon"] = true,
  ["artillery-wagon"] = true,
}

for recipe_name in pairs(blocked_train_recipes) do
  local recipe = data.raw.recipe and data.raw.recipe[recipe_name]
  if recipe then
    recipe.enabled = false
    recipe.hidden = true
    recipe.hidden_in_factoriopedia = true
  end
end

for _, technology in pairs(data.raw.technology or {}) do
  for index = #(technology.effects or {}), 1, -1 do
    local effect = technology.effects[index]
    if effect and effect.type == "unlock-recipe" and blocked_train_recipes[effect.recipe] then
      table.remove(technology.effects, index)
    end
  end
end

-- Fluid Wagon only unlocks the now-forbidden wagon recipe. Hide the empty
-- research entirely; Railway and Artillery remain available normally.
local fluid_wagon_technology = data.raw.technology
  and data.raw.technology["fluid-wagon"]
if fluid_wagon_technology then
  fluid_wagon_technology.enabled = false
  fluid_wagon_technology.hidden = true
  fluid_wagon_technology.visible_when_disabled = false
  fluid_wagon_technology.hidden_in_factoriopedia = true
end

-- Apply the approved static Train Interiors background after every dependency
-- has finished registering its menu simulations. No custom music is added.
local utility_constants = data.raw["utility-constants"]
  and data.raw["utility-constants"]["default"]

if utility_constants then
  utility_constants.main_menu_simulations = nil
  utility_constants.main_menu_background_image_location =
    "__train-interiors__/graphics/gui/train-interiors-main-menu-background.png"
  utility_constants.main_menu_background_vignette_intensity = 0
  utility_constants.main_menu_background_vignette_sharpness = 0
end

require("prototypes.everything_on_nauvis_final_fixes")
require("prototypes.enemy_expansion_final_fixes")
