# Train Interiors

Train Interiors is a standalone Factorio 2.0 mod extracted from The Cave.
It works with Base Factorio, and Space Age remains optional.

The first player of each force receives a safe starter Main Train. Explore new
Nauvis chunks to find abandoned locomotives and wagons, connect them to the Main
Train, and research higher Main Train capacity to claim more rolling stock.
Locomotives, cargo wagons, fluid wagons and artillery wagons cannot be crafted
or manually placed: all additional Main Train parts must be found in the world.
Successful finds use deterministic shuffled bags of four, so every four finds
contain one of each type while exploration can continue without a supply limit.
The Starter Train and abandoned finds use hidden Train Interiors rolling-stock
prototypes so the shared 5,000-35,000 HP Train Shield works correctly. Ordinary
vanilla rolling-stock prototypes keep their normal Factorio health, and rolling
stock created directly by another mod's script is not removed.

When dangOreus is active, Train Interiors clears only the finite solid ore in
the exact abandoned-part pad before placing its concrete, rails and rolling
stock. Oil, fluid resources, infinite nodes, water, cliffs, enemies and player
buildings remain protected. Existing pre-1.0.5 saves gradually re-check previously
rejected chunks until one abandoned part is recovered, then normal exploration
continues the unlimited four-part bag sequence.

Press Ctrl and Enter once near a connected locomotive or wagon to enter it.
Use the same control once inside the train to leave.

Version 1.0.7 adds twenty Train Battery levels, twenty Main Train Expansion
levels, one-way battery output, corrected Garden power, quality-safe item
transfer and the requested configurable gameplay systems. Protected Main Train
stock cannot be repaired by construction robots.

When Space Age and Everything On Nauvis are enabled, the central 1,000-tile
radius remains Nauvis. Newly generated terrain beyond it becomes Aquilo to the
north, Gleba to the south, Vulcanus to the west and Fulgora to the east. These
regions include the terrain, resources and hazards needed for their planetary
progression. Existing generated terrain is never rewritten.

Allow Biter Expansion uses the dense Evolution-based expansion system from The
Cave. Pollution produced inside the Train Interior or Locomotive Garden is
vented every three seconds at five times its real amount beside the live Main
Locomotive. Pollution already left at earlier train positions remains there for
Factorio to diffuse and absorb normally. Once an enemy nest is inside that
pollution, its attack group receives the moving Main Locomotive as its target.

Train Interiors intentionally does not include craftable Industrial Containers,
Industrial Loaders, chest-capacity settings, resource stack-size settings or
belt stacking. Those systems belong to the separate Early Stack Size mod, which
can be installed alongside Train Interiors but is never required by it.

No Wave Defense, underground Cave generator, tunnels, Shelter Defense,
CAVETORIO or custom music are included.
