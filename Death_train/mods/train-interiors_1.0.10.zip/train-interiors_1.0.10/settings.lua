-- Train Interiors startup and runtime settings.

local startup_settings = {
  {type = "string-setting", setting_type = "startup", name = "the-cave-everything-on-nauvis", default_value = "disabled", allowed_values = {"enabled", "disabled"}, order = "a-a"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-alien-biomes-support", default_value = "enabled", allowed_values = {"enabled", "disabled"}, order = "a-b"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-allow-biter-expansion", default_value = "enabled", allowed_values = {"enabled", "disabled"}, order = "a-c"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-darkness-infestation", default_value = "enabled", allowed_values = {"enabled", "disabled"}, order = "a-d"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-integrated-damage-indicator", default_value = "enabled", allowed_values = {"enabled", "disabled"}, order = "a-e"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-auto-inventory-repair", default_value = "enabled", allowed_values = {"enabled", "disabled"}, order = "a-f"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-underground-lighting-mode", default_value = "permanent-night", allowed_values = {"normal", "permanent-day", "permanent-night", "pitch-black"}, order = "a-g"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-ore-blood", default_value = "enabled", allowed_values = {"enabled", "disabled"}, order = "a-h"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-resource-eraser-access", default_value = "admins-only", allowed_values = {"disabled", "admins-only", "all-players"}, order = "a-i"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-starter-pack", default_value = "medium", allowed_values = {"disabled", "small", "medium", "large", "lazy"}, order = "a-j"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-minimal-wire", default_value = "enabled", allowed_values = {"enabled", "disabled"}, order = "a-k"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-lamp-post", default_value = "enabled", allowed_values = {"enabled", "disabled"}, order = "a-l"},
  {type = "string-setting", setting_type = "startup", name = "the-cave-electric-furnaces-stone-steel", default_value = "enabled", allowed_values = {"enabled", "disabled"}, order = "a-m"},

  {type = "int-setting", setting_type = "runtime-global", name = "the-cave-minimal-wire-radius", default_value = 42, minimum_value = 1, maximum_value = 1000, order = "z-a"},
  {type = "int-setting", setting_type = "runtime-global", name = "the-cave-minimal-wire-max-poles", default_value = 30, minimum_value = 2, maximum_value = 1000, order = "z-b"},
  {type = "int-setting", setting_type = "runtime-global", name = "the-cave-minimal-wire-operations-per-tick", default_value = 10, minimum_value = 1, maximum_value = 1000, order = "z-c"},
}

data:extend(startup_settings)

-- Train Interiors integrated Damage Indicator settings (Dummiez, GPLv3)
-- Integrated Damage Indicator settings (original by Dummiez, GPLv3)

local function damage_type_color_setting(name, default_value, order)
  return {
    type = "color-setting",
    name = "damage-indicator-color-" .. name,
    setting_type = "runtime-per-user",
    default_value = default_value,
    order = order
  }
end

data:extend({
  {
    type = "int-setting",
    name = "damage-indicator-lifetime",
    setting_type = "runtime-per-user",
    default_value = 72,
    minimum_value = 24,
    maximum_value = 180,
    order = "aa"
  },
  {
    type = "double-setting",
    name = "damage-indicator-animation-speed",
    setting_type = "runtime-per-user",
    default_value = 1,
    minimum_value = 0.5,
    maximum_value = 3,
    order = "ab"
  },
  {
    type = "double-setting",
    name = "damage-indicator-color-intensity-cap",
    setting_type = "runtime-per-user",
    default_value = 3000,
    minimum_value = 10,
    maximum_value = 100000,
    order = "ac"
  },
  {
    type = "string-setting",
    name = "damage-indicator-color-mode",
    setting_type = "runtime-per-user",
    default_value = "damage-type",
    allowed_values = { "damage-type", "damage-ramp" },
    order = "ad"
  },
  {
    type = "bool-setting",
    name = "damage-indicator-blend-damage-type-colors",
    setting_type = "runtime-per-user",
    default_value = true,
    order = "ad2"
  },
  damage_type_color_setting("physical", { r = 255 / 255, g = 241 / 255, b = 92 / 255 }, "ad3a"),
  damage_type_color_setting("impact", { r = 255 / 255, g = 216 / 255, b = 187 / 255 }, "ad3b"),
  damage_type_color_setting("explosion", { r = 255 / 255, g = 92 / 255, b = 40 / 255 }, "ad3c"),
  damage_type_color_setting("fire", { r = 226 / 255, g = 132 / 255, b = 28 / 255 }, "ad3d"),
  damage_type_color_setting("laser", { r = 255 / 255, g = 112 / 255, b = 104 / 255 }, "ad3e"),
  damage_type_color_setting("electric", { r = 94 / 255, g = 218 / 255, b = 255 / 255 }, "ad3f"),
  damage_type_color_setting("acid", { r = 168 / 255, g = 210 / 255, b = 82 / 255 }, "ad3g"),
  damage_type_color_setting("poison", { r = 205 / 255, g = 146 / 255, b = 255 / 255 }, "ad3h"),
  {
    type = "string-setting",
    name = "damage-indicator-font-family",
    setting_type = "runtime-per-user",
    default_value = "default-bold",
    allowed_values = { "default-bold", "default-semibold", "default", "default-mono" },
    order = "ae"
  },
  {
    type = "int-setting",
    name = "damage-indicator-font-size",
    setting_type = "runtime-per-user",
    default_value = 16,
    minimum_value = 8,
    maximum_value = 64,
    order = "af"
  },
  {
    type = "bool-setting",
    name = "damage-indicator-color-intensity",
    setting_type = "runtime-per-user",
    default_value = true,
    order = "ag"
  },
  {
    type = "double-setting",
    name = "damage-indicator-drift-distance",
    setting_type = "runtime-per-user",
    default_value = 3,
    minimum_value = 0,
    maximum_value = 10,
    order = "ah"
  },
  {
    type = "string-setting",
    name = "damage-indicator-drift-style",
    setting_type = "runtime-per-user",
    default_value = "away-from-shooter",
    allowed_values = { "away-from-shooter", "upward", "mixed" },
    order = "ai"
  },
  {
    type = "int-setting",
    name = "damage-indicator-max-active",
    setting_type = "runtime-global",
    default_value = 300,
    minimum_value = 100,
    maximum_value = 1000,
    order = "ak"
  },
  {
    type = "double-setting",
    name = "damage-indicator-group-similar-distance",
    setting_type = "runtime-global",
    default_value = 5,
    minimum_value = 0,
    maximum_value = 20,
    order = "ak2"
  },
  {
    type = "string-setting",
    name = "damage-indicator-whitelist-entity-types",
    setting_type = "runtime-global",
    default_value = "asteroid",
    allow_blank = true,
    order = "ak2a"
  },
  {
    type = "double-setting",
    name = "damage-indicator-whitelist-distance-bonus",
    setting_type = "runtime-global",
    default_value = 15,
    minimum_value = 0,
    maximum_value = 50,
    order = "ak2b"
  },
  {
    type = "int-setting",
    name = "damage-indicator-saturation-threshold",
    setting_type = "runtime-global",
    default_value = 10,
    minimum_value = 2,
    maximum_value = 50,
    order = "ak2b2"
  },
  {
    type = "string-setting",
    name = "damage-indicator-blacklist-entity-names",
    setting_type = "runtime-global",
    default_value = "",
    allow_blank = true,
    order = "ak2c"
  },
  {
    -- Group-key normalization patterns for entities whose internal names contain
    -- a versioned/tiered suffix (e.g. Rampant's `spitter-spawn-v1-t10-rampant`,
    -- `behemoth-biter-v3-t8-rampant`). Each comma-separated entry is a Lua pattern
    -- with ONE capture group `(...)` that extracts the base name. The captured
    -- portion becomes the grouping identity (so all variants merge) and is also
    -- title-cased for display in the group count tag. Patterns are tried in order;
    -- the first match wins. Use `%-` to escape literal hyphens in patterns.
    -- Empty value disables normalization. Eg: ^(.-)%-v%d+%-t%d+%-rampant$
    type = "string-setting",
    name = "damage-indicator-group-name-normalize",
    setting_type = "runtime-global",
    default_value = "^(.-)%-v%d+%-t%d+.*$",
    allow_blank = true,
    order = "ak2d"
  },
  {
    type = "bool-setting",
    name = "damage-indicator-show-group-count",
    setting_type = "runtime-per-user",
    default_value = true,
    order = "ak3"
  },
  {
    type = "int-setting",
    name = "damage-indicator-combine-ticks",
    setting_type = "runtime-global",
    default_value = 30,
    minimum_value = 6,
    maximum_value = 120,
    order = "am"
  },
  {
    type = "string-setting",
    name = "damage-indicator-font",
    setting_type = "runtime-global",
    default_value = "damage-indicator-font",
    allowed_values = {
      "damage-indicator-font",
      "compi",
      "console",
      "count-font",
      "debug",
      "debug-mono",
      "default",
      "default-bold",
      "default-dialog-button",
      "default-dropdown",
      "default-game",
      "default-game-font",
      "default-large",
      "default-large-bold",
      "default-large-semibold",
      "default-listbox",
      "default-semibold",
      "default-small",
      "default-small-bold",
      "default-small-semibold",
      "default-tiny-bold",
      "heading-1",
      "heading-2",
      "infinite",
      "item-count",
      "locale-pick",
      "scenario-message-dialog",
      "technology-slot-level-font",
      "var"
    },
    order = "aea"
  },
  {
    type = "bool-setting",
    name = "damage-indicator-compact-numbers",
    setting_type = "runtime-per-user",
    default_value = false,
    order = "ao"
  },
  {
    type = "string-setting",
    name = "damage-indicator-number-separator",
    setting_type = "runtime-per-user",
    default_value = "commas",
    allowed_values = { "none", "commas", "points" },
    order = "ao2"
  },
  {
    type = "string-setting",
    name = "damage-indicator-shadow-style",
    setting_type = "runtime-per-user",
    default_value = "light",
    allowed_values = { "off", "light", "heavy" },
    order = "ap"
  },
  {
    type = "bool-setting",
    name = "damage-indicator-show-reductions",
    setting_type = "runtime-per-user",
    default_value = true,
    order = "ar"
  },
  {
    type = "bool-setting",
    name = "damage-indicator-alt-mode",
    setting_type = "runtime-per-user",
    default_value = false,
    order = "ar2"
  },
  {
    type = "bool-setting",
    name = "damage-indicator-debug-info",
    setting_type = "runtime-per-user",
    default_value = false,
    order = "az3"
  },
  {
    type = "string-setting",
    name = "damage-indicator-text-template",
    setting_type = "runtime-per-user",
    default_value = "__damage__",
    order = "at"
  },
  {
    type = "int-setting",
    name = "damage-indicator-text-update-interval",
    setting_type = "runtime-global",
    default_value = 6,
    minimum_value = 1,
    maximum_value = 60,
    order = "au"
  },
  -- Server-side override for per-user display settings. When a valid encoded string
  -- is present, all players see indicators using the encoded settings (with the
  -- exception of `damage-indicator-enabled`, which each player still controls). Use
  -- the in-game command /damage-indicators-override to produce a string from
  -- the current player's settings, then paste it into this setting.
  {
    type = "string-setting",
    name = "damage-indicator-server-override-string",
    setting_type = "runtime-global",
    default_value = "",
    allow_blank = true,
    order = "zz2"
  },
  -- {
  --   type = "bool-setting",
  --   name = "damage-indicator-rich-text",
  --   setting_type = "startup",
  --   default_value = true,
  --   order = "av"
  -- },
  {
    type = "bool-setting",
    name = "damage-indicator-viewport-culling",
    setting_type = "runtime-global",
    default_value = true,
    order = "aw"
  },
  {
    type = "double-setting",
    name = "damage-indicator-viewport-margin",
    setting_type = "runtime-global",
    default_value = 12,
    minimum_value = 0,
    maximum_value = 100,
    order = "ax"
  },
  {
    type = "bool-setting",
    name = "damage-indicator-killing-blow",
    setting_type = "runtime-per-user",
    default_value = true,
    order = "az"
  },
  {
    type = "string-setting",
    name = "damage-indicator-killing-blow-marker",
    setting_type = "runtime-per-user",
    default_value = "!",
    allow_blank = true,
    order = "az2"
  },
  {
    type = "bool-setting",
    name = "damage-indicator-enabled",
    setting_type = "runtime-per-user",
    default_value = true,
    order = "aa1"
  },
  {
    type = "int-setting",
    name = "damage-indicator-radius",
    setting_type = "runtime-per-user",
    default_value = 80,
    minimum_value = 10,
    maximum_value = 200,
    order = "aa2"
  },
  {
    type = "string-setting",
    name = "damage-indicator-visibility",
    setting_type = "runtime-per-user",
    default_value = "nearby",
    allowed_values = { "nearby", "own-force", "outgoing" },
    order = "aa3"
  },
  {
    type = "double-setting",
    name = "damage-indicator-scale",
    setting_type = "runtime-per-user",
    default_value = 1,
    minimum_value = 0.5,
    maximum_value = 2,
    order = "aa4"
  },
  {
    type = "double-setting",
    name = "damage-indicator-minimum-damage",
    setting_type = "runtime-per-user",
    default_value = 0.1,
    minimum_value = 0,
    maximum_value = 1000,
    order = "aa5"
  },
})
