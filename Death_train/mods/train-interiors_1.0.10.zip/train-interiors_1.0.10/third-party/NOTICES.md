# Third-party notices

Train Interiors is distributed under GNU GPLv3; see `LICENSE`.

## Industrial container artwork

The 2x2 and 6x6 transfer-container artwork and original design are based on
**Exotic Industries: Containers** by PreLeyZero, distributed under GNU GPLv3.

## Damage Indicator

The integrated Damage Indicator is adapted from work by Dummiez and is
distributed under GNU GPLv3.

## Auto Inventory Repair

Auto Inventory Repair is adapted from **Inventory Repair** by calcwizard,
distributed under the MIT License reproduced below.

## Electric furnaces

The electric stone and steel furnace implementation and artwork are adapted
from **Electric Furnaces 2.5.2** by GotLag. The integrated version is
distributed as part of this GNU GPLv3 package.

## Fluid tank artwork and implementation

The 5x5 transfer-tank artwork and supporting implementation are derived from
**Zithorian's Extra Storage Tanks** and its Factorio 2.0 port, distributed
under the MIT License. Copyright remains with the respective authors.

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
