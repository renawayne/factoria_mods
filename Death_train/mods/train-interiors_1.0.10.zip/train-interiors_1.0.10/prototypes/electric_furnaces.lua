-- Train Interiors integrated early electric furnaces.
-- Adapted from Electric Furnaces 2.5.2 by GotLag.

local setting = settings.startup["the-cave-electric-furnaces-stone-steel"]
if setting and setting.value == "disabled" then return end

local item_sounds = require("__base__.prototypes.item_sounds")

local electric_stone = table.deepcopy(data.raw.furnace["stone-furnace"])
electric_stone.name = "electric-stone-furnace"
electric_stone.icon = "__train-interiors__/graphics/icons/electric-stone-furnace.png"
electric_stone.minable.result = "electric-stone-furnace"
electric_stone.next_upgrade = "electric-steel-furnace"
electric_stone.working_sound.sound.filename = "__base__/sound/electric-furnace.ogg"
electric_stone.energy_usage = "90kW"
electric_stone.crafting_speed = 1
electric_stone.energy_source = {
  type = "electric",
  usage_priority = "secondary-input",
  emissions_per_minute = {pollution = 1}
}
electric_stone.graphics_set.animation.layers[1].filename =
  "__train-interiors__/graphics/entity/electric-stone-furnace/electric-stone-furnace.png"
electric_stone.graphics_set.working_visualisations[1].effect = nil
electric_stone.graphics_set.working_visualisations[1].animation.layers[1] = {
  filename = "__train-interiors__/graphics/entity/electric-stone-furnace/electric-stone-furnace-heater.png",
  priority = "extra-high",
  width = 16,
  height = 27,
  frame_count = 12,
  animation_speed = 0.5,
  draw_as_glow = true,
  shift = util.by_pixel(0.5, 18),
  scale = 0.5
}
electric_stone.graphics_set.working_visualisations[1].animation.layers[2].repeat_count = 12
electric_stone.graphics_set.working_visualisations[2].effect = nil
electric_stone.graphics_set.working_visualisations[2].animation.repeat_count = 12

local electric_steel = table.deepcopy(data.raw.furnace["steel-furnace"])
electric_steel.name = "electric-steel-furnace"
electric_steel.icon = "__train-interiors__/graphics/icons/electric-steel-furnace.png"
electric_steel.minable.result = "electric-steel-furnace"
electric_steel.working_sound.sound.filename = "__base__/sound/electric-furnace.ogg"
electric_steel.energy_usage = "180kW"
electric_steel.crafting_speed = 2
electric_steel.energy_source = {
  type = "electric",
  usage_priority = "secondary-input",
  emissions_per_minute = {pollution = 2}
}
electric_steel.graphics_set.animation.layers[1].filename =
  "__train-interiors__/graphics/entity/electric-steel-furnace/electric-steel-furnace.png"
electric_steel.graphics_set.working_visualisations[1] = {
  fadeout = true,
  animation = {
    filename = "__train-interiors__/graphics/entity/electric-steel-furnace/electric-steel-furnace-heater.png",
    priority = "high",
    width = 48,
    height = 20,
    frame_count = 12,
    draw_as_glow = true,
    shift = util.by_pixel(0, 20.5),
    scale = 0.5
  }
}
electric_steel.graphics_set.working_visualisations[2].effect = nil
electric_steel.graphics_set.working_visualisations[3].effect = nil
electric_steel.graphics_set.working_visualisations[4].effect = nil

data:extend({
  electric_stone,
  electric_steel,
  {
    type = "item",
    name = "electric-stone-furnace",
    icon = "__train-interiors__/graphics/icons/electric-stone-furnace.png",
    subgroup = "smelting-machine",
    order = "a[stone-furnace]b",
    place_result = "electric-stone-furnace",
    inventory_move_sound = item_sounds.brick_inventory_move,
    pick_sound = item_sounds.brick_inventory_pickup,
    drop_sound = item_sounds.brick_inventory_move,
    stack_size = 50
  },
  {
    type = "item",
    name = "electric-steel-furnace",
    icon = "__train-interiors__/graphics/icons/electric-steel-furnace.png",
    subgroup = "smelting-machine",
    order = "b[steel-furnace]b",
    place_result = "electric-steel-furnace",
    inventory_move_sound = item_sounds.metal_large_inventory_move,
    pick_sound = item_sounds.metal_large_inventory_pickup,
    drop_sound = item_sounds.metal_large_inventory_move,
    stack_size = 50
  },
  {
    type = "recipe",
    name = "electric-stone-furnace",
    icon = "__train-interiors__/graphics/icons/electric-stone-furnace-i.png",
    ingredients = {
      {type = "item", name = "stone-furnace", amount = 1},
      {type = "item", name = "electronic-circuit", amount = 1},
      {type = "item", name = "iron-plate", amount = 1}
    },
    results = {{type = "item", name = "electric-stone-furnace", amount = 1}},
    enabled = false
  },
  {
    type = "recipe",
    name = "electric-steel-furnace",
    icon = "__train-interiors__/graphics/icons/electric-steel-furnace-i.png",
    ingredients = {
      {type = "item", name = "steel-furnace", amount = 1},
      {type = "item", name = "electronic-circuit", amount = 5},
      {type = "item", name = "iron-plate", amount = 5}
    },
    results = {{type = "item", name = "electric-steel-furnace", amount = 1}},
    energy_required = 3,
    enabled = false
  }
})

table.insert(data.raw.technology["electronics"].effects, {
  type = "unlock-recipe",
  recipe = "electric-stone-furnace"
})
table.insert(data.raw.technology["advanced-material-processing"].effects, {
  type = "unlock-recipe",
  recipe = "electric-steel-furnace"
})
