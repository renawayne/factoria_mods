-- Standalone Train Interiors progression. Every chain uses Base-game science;
-- Space Age enriches optional content but is never required to load or play.

local technologies = {}

local function ingredients(names)
  local result = {}
  for _, name in ipairs(names) do result[#result + 1] = {name, 1} end
  return result
end

local function add_gate(list, name)
  if name and data.raw.technology and data.raw.technology[name] then
    list[#list + 1] = name
  end
end

local battery = {
  {capacity = 2000, count = 200, packs = {"automation-science-pack"}},
  {capacity = 2500, count = 400, packs = {"automation-science-pack"}},
  {capacity = 3200, count = 600, packs = {"automation-science-pack"}},
  {capacity = 4200, count = 800, packs = {"automation-science-pack", "logistic-science-pack"}},
  {capacity = 5500, count = 1000, packs = {"automation-science-pack", "logistic-science-pack"}},
  {capacity = 7000, count = 1200, packs = {"automation-science-pack", "logistic-science-pack"}},
  {capacity = 9000, count = 1400, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack"}},
  {capacity = 12000, count = 1600, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack"}},
  {capacity = 15000, count = 1800, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack"}},
  {capacity = 20000, count = 2000, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack"}},
  {capacity = 25000, count = 2200, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack"}},
  {capacity = 32000, count = 2400, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack"}},
  {capacity = 42000, count = 2600, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack"}},
  {capacity = 55000, count = 2800, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack"}},
  {capacity = 70000, count = 3000, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack"}},
  {capacity = 90000, count = 3200, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}},
  {capacity = 120000, count = 3400, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}},
  {capacity = 150000, count = 3600, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}},
  {capacity = 200000, count = 3800, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}},
  {capacity = 250000, count = 4000, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}},
}

for level, def in ipairs(battery) do
  local prerequisites = {}
  if level > 1 then prerequisites[#prerequisites + 1] = "the-cave-train-battery-upgrade-" .. (level - 1) end
  technologies[#technologies + 1] = {
    type = "technology",
    name = "the-cave-train-battery-upgrade-" .. level,
    localised_name = {"technology-name.train-interiors-battery", tostring(level)},
    localised_description = {"technology-description.train-interiors-battery", tostring(def.capacity)},
    icons = {{icon = "__train-interiors__/graphics/technology/train-battery.png", icon_size = 256}},
    effects = {{type = "nothing", effect_description = {"technology-effect.train-interiors-battery", tostring(def.capacity)}}},
    prerequisites = #prerequisites > 0 and prerequisites or nil,
    unit = {count = def.count, ingredients = ingredients(def.packs), time = 15},
    order = "train-interiors-a-battery-" .. string.format("%02d", level)
  }
end

local interiors = {
  {width = 60, height = 60, connector = 60, count = 100, packs = {"automation-science-pack"}},
  {width = 80, height = 80, connector = 80, count = 280, gate = "logistic-science-pack", packs = {"automation-science-pack", "logistic-science-pack"}},
  {width = 92, height = 100, connector = 100, count = 460, gate = "military-science-pack", packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack"}},
  {width = 92, height = 160, connector = 160, count = 640, gate = "chemical-science-pack", packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack"}},
  {width = 92, height = 220, connector = 220, count = 820, gate = "production-science-pack", packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack"}},
  {width = 92, height = 280, connector = 280, count = 1000, gate = "utility-science-pack", packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}}
}

for level, def in ipairs(interiors) do
  local prerequisites = {}
  if level > 1 then prerequisites[#prerequisites + 1] = "the-cave-train-interior-expansion-" .. (level - 1) end
  add_gate(prerequisites, def.gate)
  technologies[#technologies + 1] = {
    type = "technology",
    name = "the-cave-train-interior-expansion-" .. level,
    localised_name = {"technology-name.train-interiors-room", tostring(level)},
    localised_description = {"technology-description.train-interiors-room", tostring(def.width), tostring(def.height), tostring(def.connector)},
    icons = {{icon = "__train-interiors__/graphics/technology/train-interior-expansion.png", icon_size = 256}},
    effects = {{type = "nothing", effect_description = {"technology-effect.train-interiors-room", tostring(def.width), tostring(def.height), tostring(def.connector)}}},
    prerequisites = #prerequisites > 0 and prerequisites or nil,
    unit = {count = def.count, ingredients = ingredients(def.packs), time = 30},
    order = "train-interiors-b-room-" .. string.format("%02d", level)
  }
end

local main_train = {
  {capacity = 4, count = 200, packs = {"automation-science-pack"}},
  {capacity = 5, count = 400, packs = {"automation-science-pack"}},
  {capacity = 6, count = 600, packs = {"automation-science-pack"}},
  {capacity = 7, count = 800, gate = "logistic-science-pack", packs = {"automation-science-pack", "logistic-science-pack"}},
  {capacity = 8, count = 1000, packs = {"automation-science-pack", "logistic-science-pack"}},
  {capacity = 9, count = 1200, packs = {"automation-science-pack", "logistic-science-pack"}},
  {capacity = 10, count = 1400, gate = "military-science-pack", packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack"}},
  {capacity = 11, count = 1600, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack"}},
  {capacity = 12, count = 1800, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack"}},
  {capacity = 13, count = 2000, gate = "chemical-science-pack", packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack"}},
  {capacity = 14, count = 2200, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack"}},
  {capacity = 15, count = 2400, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack"}},
  {capacity = 16, count = 2600, gate = "production-science-pack", packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack"}},
  {capacity = 17, count = 2800, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack"}},
  {capacity = 18, count = 3000, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack"}},
  {capacity = 19, count = 3200, gate = "utility-science-pack", packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}},
  {capacity = 20, count = 3400, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}},
  {capacity = 21, count = 3600, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}},
  {capacity = 22, count = 3800, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}},
  {capacity = 23, count = 4000, packs = {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}},
}

for level, def in ipairs(main_train) do
  local prerequisites = {"the-cave-train-interior-expansion-" .. math.min(level, #interiors)}
  if level > 1 then prerequisites[#prerequisites + 1] = "the-cave-main-train-expansion-" .. (level - 1) end
  add_gate(prerequisites, def.gate)
  technologies[#technologies + 1] = {
    type = "technology",
    name = "the-cave-main-train-expansion-" .. level,
    localised_name = {"technology-name.train-interiors-capacity", tostring(level)},
    localised_description = {"technology-description.train-interiors-capacity", tostring(def.capacity)},
    icons = {{icon = "__train-interiors__/graphics/technology/main-train-expansion.png", icon_size = 256}},
    effects = {{type = "nothing", effect_description = {"technology-effect.train-interiors-capacity", tostring(def.capacity)}}},
    prerequisites = prerequisites,
    unit = {count = def.count, ingredients = ingredients(def.packs), time = 30},
    order = "train-interiors-c-capacity-" .. string.format("%02d", level)
  }
end

local shield_packs = {
  {"automation-science-pack"},
  {"automation-science-pack", "logistic-science-pack"},
  {"automation-science-pack", "logistic-science-pack", "military-science-pack"},
  {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack"},
  {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack"},
  {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack"},
  {"automation-science-pack", "logistic-science-pack", "military-science-pack", "chemical-science-pack", "production-science-pack", "utility-science-pack"}
}

for level = 1, 10 do
  local health = 5000 + 3000 * level
  local repair = 5 * level
  local prerequisites = {}
  if level > 1 then prerequisites[#prerequisites + 1] = "the-cave-train-shield-upgrade-" .. (level - 1) end
  if level <= 6 then prerequisites[#prerequisites + 1] = "the-cave-train-battery-upgrade-" .. level end
  local packs = shield_packs[math.min(level, #shield_packs)]
  technologies[#technologies + 1] = {
    type = "technology",
    name = "the-cave-train-shield-upgrade-" .. level,
    localised_name = {"technology-name.train-interiors-shield", tostring(level)},
    localised_description = {"technology-description.train-interiors-shield", tostring(health), tostring(repair)},
    icons = {{icon = "__train-interiors__/graphics/technology/train-shield.png", icon_size = 256}},
    effects = {
      {type = "nothing", effect_description = {"technology-effect.train-interiors-shield-health", tostring(health)}},
      {type = "nothing", effect_description = {"technology-effect.train-interiors-shield-repair", tostring(repair)}}
    },
    prerequisites = #prerequisites > 0 and prerequisites or nil,
    unit = {count = 200 * level, ingredients = ingredients(packs), time = 30},
    order = "train-interiors-d-shield-" .. string.format("%02d", level)
  }
end

local garden = {
  {count = 200, gate = "logistic-science-pack", packs = {"automation-science-pack", "logistic-science-pack"}},
  {count = 400, gate = "chemical-science-pack", packs = {"automation-science-pack", "logistic-science-pack", "chemical-science-pack"}},
  {count = 600, gate = "production-science-pack", packs = {"automation-science-pack", "logistic-science-pack", "chemical-science-pack", "production-science-pack"}}
}

for level, def in ipairs(garden) do
  local prerequisites = {}
  if level > 1 then prerequisites[#prerequisites + 1] = "the-cave-locomotive-garden-" .. (level - 1) end
  if level == 1 then prerequisites[#prerequisites + 1] = "the-cave-train-interior-expansion-2" end
  add_gate(prerequisites, def.gate)
  technologies[#technologies + 1] = {
    type = "technology",
    name = "the-cave-locomotive-garden-" .. level,
    localised_name = {"technology-name.train-interiors-garden", tostring(level)},
    localised_description = {"technology-description.train-interiors-garden", tostring(level)},
    icons = {{icon = "__train-interiors__/graphics/technology/locomotive-garden.png", icon_size = 256}},
    effects = {{type = "nothing", effect_description = {"technology-effect.train-interiors-garden", tostring(level)}}},
    prerequisites = prerequisites,
    unit = {count = def.count, ingredients = ingredients(def.packs), time = 30},
    order = "train-interiors-e-garden-" .. string.format("%02d", level)
  }
end

data:extend(technologies)

