-- Standalone-safe Everything On Nauvis progression.
-- It removes only official surface gates and keeps every planet available.

local setting = settings.startup["the-cave-everything-on-nauvis"]
local enabled = setting and setting.value == "enabled"
if not (enabled and mods and mods["space-age"]) then return end

local function remove_condition(recipe_name, predicate)
  local recipe = data.raw.recipe and data.raw.recipe[recipe_name]
  if not (recipe and type(recipe.surface_conditions) == "table") then return end
  local kept = {}
  for _, condition in ipairs(recipe.surface_conditions) do
    if not predicate(condition) then kept[#kept + 1] = condition end
  end
  recipe.surface_conditions = #kept > 0 and kept or nil
end

for _, name in ipairs({
  "copper-bacteria", "copper-bacteria-cultivation",
  "iron-bacteria", "iron-bacteria-cultivation",
  "artificial-yumako-soil", "overgrowth-yumako-soil",
  "artificial-jellynut-soil", "overgrowth-jellynut-soil",
  "pentapod-egg", "agricultural-science-pack", "biochamber",
}) do
  remove_condition(name, function(c)
    return type(c) == "table" and c.property == "pressure"
      and c.min == 2000 and c.max == 2000
  end)
end

for _, name in ipairs({
  "acid-neutralisation", "foundry", "metallurgic-science-pack",
  "turbo-transport-belt", "turbo-underground-belt", "turbo-splitter",
  "big-mining-drill",
}) do
  remove_condition(name, function(c)
    return type(c) == "table" and c.property == "pressure"
      and c.min == 4000 and c.max == 4000
  end)
end

for _, name in ipairs({
  "cryogenic-science-pack", "cryogenic-plant", "fusion-reactor",
  "fusion-generator", "quantum-processor",
}) do
  remove_condition(name, function(c)
    return type(c) == "table" and c.property == "pressure"
  end)
end

for _, name in ipairs({
  "electromagnetic-science-pack", "lightning-rod", "lightning-collector",
  "electromagnetic-plant", "recycler",
}) do
  remove_condition(name, function(c)
    return type(c) == "table" and c.property == "magnetic-field"
  end)
end

remove_condition("space-science-pack", function(c)
  return type(c) == "table" and c.property == "gravity"
    and c.min == 0 and c.max == 0
end)

local technology = data.raw.technology and data.raw.technology["space-science-pack"]
if technology then
  local prerequisites = {}
  local seen = {}
  for _, prerequisite in ipairs(technology.prerequisites or {}) do
    if prerequisite ~= "space-platform" and not seen[prerequisite] then
      prerequisites[#prerequisites + 1] = prerequisite
      seen[prerequisite] = true
    end
  end
  for _, prerequisite in ipairs({"processing-unit", "low-density-structure"}) do
    if data.raw.technology[prerequisite] and not seen[prerequisite] then
      prerequisites[#prerequisites + 1] = prerequisite
      seen[prerequisite] = true
    end
  end
  technology.prerequisites = prerequisites
  technology.research_trigger = nil
  technology.unit = {
    count = 100,
    ingredients = {
      {"metallurgic-science-pack", 1},
      {"agricultural-science-pack", 1},
      {"chemical-science-pack", 1},
      {"electromagnetic-science-pack", 1},
    },
    time = 60,
  }
end

-- Nauvis needs Fulgora's lightning target rules before scripted regional
-- strikes can use LuaSurface.execute_lightning. Automatic planet-wide strikes
-- remain disabled; runtime code strikes only inside the eastern Fulgora wedge.
local planets = data.raw.planet
local nauvis = planets and planets.nauvis
local fulgora = planets and planets.fulgora
local lightning = fulgora and fulgora.lightning_properties
if nauvis and lightning then
  local properties = table.deepcopy(lightning)
  properties.lightning_multiplier_at_day = 0
  properties.lightning_multiplier_at_night = 0
  properties.lightning_warning_icon = {
    filename = "__core__/graphics/empty.png",
    width = 1,
    height = 1,
  }
  nauvis.lightning_properties = properties
end
