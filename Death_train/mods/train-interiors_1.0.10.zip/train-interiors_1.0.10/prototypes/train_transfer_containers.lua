-- Protected item-transfer fixtures used by Train Interiors only.
-- Artwork and original design are based on Exotic Industries: Containers by PreLeyZero.

local entity_path = "__train-interiors__/graphics/entity/industrial-containers/"
local icon_path = "__train-interiors__/graphics/icons/industrial-containers/"
local steel_chest = data.raw.container and data.raw.container["steel-chest"]

if not steel_chest then return end

local definitions = {
  {
    name = "the-cave-2x2-container",
    label = "2x2",
    size = 2,
    inventory_size = 200,
    image_size = 512,
    scale = 0.26,
    max_health = 800
  },
  {
    name = "the-cave-6x6-container",
    label = "6x6",
    size = 6,
    inventory_size = 1000,
    image_size = 1024,
    scale = 0.39,
    max_health = 2500
  }
}

local prototypes = {}
for _, def in ipairs(definitions) do
  if not (data.raw.container and data.raw.container[def.name]) then
    -- Build the protected fixture from a normal, loader-compatible container
    -- prototype. Early Stack Size supplies the exact public Industrial
    -- Container when installed; the vanilla Steel Chest is the standalone
    -- fallback. Runtime creation still makes every fixture non-minable and
    -- indestructible, so no recipe or placeable item is exposed to players.
    local template_name = "early-stack-size-" .. def.label .. "-container"
    local template = data.raw.container[template_name] or steel_chest
    local entity = table.deepcopy(template)

    entity.type = "container"
    entity.name = def.name
    entity.localised_name = {"entity-name." .. def.name}
    entity.localised_description = {"entity-description." .. def.name}
    entity.icon = icon_path .. def.label .. "-container.png"
    entity.icons = nil

    entity.flags = table.deepcopy(template.flags or {})
    local known_flags = {}
    for _, flag in pairs(entity.flags) do known_flags[flag] = true end
    for _, flag in ipairs({
      "placeable-neutral",
      "player-creation",
      "not-blueprintable",
      "not-deconstructable",
      "not-flammable"
    }) do
      if not known_flags[flag] then entity.flags[#entity.flags + 1] = flag end
    end

    entity.hidden = true
    entity.hidden_in_factoriopedia = true
    entity.minable = {mining_time = 1}
    entity.placeable_by = nil
    entity.fast_replaceable_group = nil
    entity.next_upgrade = nil
    entity.max_health = def.max_health
    entity.corpse = nil
    entity.dying_explosion = nil
    entity.damaged_trigger_effect = table.deepcopy(steel_chest.damaged_trigger_effect)
    entity.resistances = table.deepcopy(steel_chest.resistances)
    entity.open_sound = table.deepcopy(steel_chest.open_sound)
    entity.close_sound = table.deepcopy(steel_chest.close_sound)
    entity.impact_category = steel_chest.impact_category
    entity.selection_box = {{-def.size / 2, -def.size / 2}, {def.size / 2, def.size / 2}}
    entity.collision_box = {
      {-def.size / 2 + 0.15, -def.size / 2 + 0.15},
      {def.size / 2 - 0.15, def.size / 2 - 0.15}
    }
    entity.tile_width = def.size
    entity.tile_height = def.size
    entity.inventory_size = def.inventory_size
    entity.inventory_type = "with_bar"
    entity.picture = {
      layers = {
        {
          filename = entity_path .. def.label .. "-container.png",
          priority = "extra-high",
          width = def.image_size,
          height = def.image_size,
          scale = def.scale
        },
        {
          filename = entity_path .. def.label .. "-container_shadow.png",
          priority = "extra-high",
          width = def.image_size,
          height = def.image_size,
          scale = def.scale,
          draw_as_shadow = true
        }
      }
    }
    entity.circuit_connector = table.deepcopy(steel_chest.circuit_connector)
    entity.circuit_wire_max_distance = steel_chest.circuit_wire_max_distance
    entity.scale_info_icons = true

    prototypes[#prototypes + 1] = entity
  end
end

if #prototypes > 0 then data:extend(prototypes) end
