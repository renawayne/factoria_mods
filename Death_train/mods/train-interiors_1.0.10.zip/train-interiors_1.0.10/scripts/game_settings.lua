-- Compatibility shim for integrated standalone modules.
local M = {}

function M.proxy(value)
  return value
end

return M
