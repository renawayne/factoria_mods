-- Directional Space Age regions on the ordinary Nauvis surface.
-- Only newly generated tiles beyond the central 1000-tile radius are changed.
local hash = require("scripts.lib.hash")
local Simplex = require("scripts.lib.simplex")

local M = {}

local SETTING_NAME = "the-cave-everything-on-nauvis"
local CENTRAL_RADIUS_SQUARED = 1000 * 1000
local GENERATION_VERSION = 1
local STATE_KEY = "train_interiors_planet_regions"
local TENDRIL_SCALE = 1 / 40

local REGION_TILES = {
  gleba = {
    "natural-yumako-soil", "natural-jellynut-soil", "wetland-yumako", "wetland-jellynut",
    "lowland-red-infection", "lowland-red-vein", "lowland-red-vein-2",
    "lowland-olive-blubber", "lowland-brown-blubber", "lowland-cream-red",
  },
  vulcanus = {
    "volcanic-soil-dark", "volcanic-soil-light", "volcanic-ash-dark", "volcanic-ash-light",
    "volcanic-cracks", "volcanic-folds", "volcanic-pumice-stones", "volcanic-smooth-stone",
  },
  fulgora = {
    "fulgoran-dunes", "fulgoran-dust", "fulgoran-rock", "fulgoran-sand",
    "fulgoran-machinery", "fulgoran-paving",
  },
  aquilo = {
    "snow-flat", "snow-crests", "snow-lumpy", "snow-patchy",
    "ice-rough", "ice-smooth", "brash-ice",
  },
}

local RESOURCE_SETS = {
  vulcanus = {
    {name = "tungsten-ore", noise_seed = 3210, width = 0.0060, amount = {350, 950}},
    {name = "calcite", noise_seed = 3220, width = 0.0100, amount = {450, 1250}},
    {name = "coal", noise_seed = 3230, width = 0.0120, amount = {400, 1200}},
    {name = "sulfuric-acid-geyser", noise_seed = 3240, width = 0.0032,
      amount = {500000, 1000000}, min_spacing = 9},
  },
  fulgora = {
    {name = "scrap", noise_seed = 3310, width = 0.0150, amount = {300, 1200}},
  },
  gleba = {
    {name = "stone", noise_seed = 3410, width = 0.0080, amount = {300, 950}},
    {name = "iron-stromatolite", noise_seed = 3420, width = 0.0070,
      kind = "natural-entity", min_spacing = 4, tile = "lowland-red-vein"},
    {name = "copper-stromatolite", noise_seed = 3430, width = 0.0070,
      kind = "natural-entity", min_spacing = 4, tile = "lowland-olive-blubber"},
  },
  aquilo = {
    {name = "crude-oil", noise_seed = 3510, width = 0.0030,
      amount = {1500000, 3000000}, min_spacing = 10,
      spacing_names = {"crude-oil", "lithium-brine", "fluorine-vent"}},
    {name = "lithium-brine", noise_seed = 3520, width = 0.0040,
      amount = {60000, 220000}, min_spacing = 9,
      spacing_names = {"crude-oil", "lithium-brine", "fluorine-vent"}},
    {name = "fluorine-vent", noise_seed = 3530, width = 0.0032,
      amount = {50000, 180000}, min_spacing = 9,
      spacing_names = {"crude-oil", "lithium-brine", "fluorine-vent"}},
    {name = "lithium-iceberg-big", noise_seed = 3540, width = 0.0022,
      kind = "natural-entity", min_spacing = 18},
    {name = "lithium-iceberg-huge", noise_seed = 3550, width = 0.0009,
      kind = "natural-entity", min_spacing = 36},
  },
}

local GLEBA_PLANTS = {
  {name = "yumako-tree", weight = 120, tile = "natural-yumako-soil"},
  {name = "jellystem", weight = 120, tile = "natural-jellynut-soil"},
  {name = "cuttlepop", weight = 8, tile = "lowland-red-vein"},
  {name = "sunnycomb", weight = 8, tile = "lowland-red-infection"},
  {name = "slipstack", weight = 8, tile = "wetland-yumako"},
  {name = "funneltrunk", weight = 8, tile = "wetland-jellynut"},
  {name = "hairyclubnub", weight = 8, tile = "lowland-olive-blubber"},
  {name = "teflilly", weight = 8, tile = "lowland-cream-red"},
  {name = "lickmaw", weight = 8, tile = "lowland-red-vein-2"},
  {name = "stingfrond", weight = 8, tile = "lowland-red-vein-3"},
  {name = "boompuff", weight = 8, tile = "lowland-brown-blubber"},
  {name = "water-cane", weight = 8, tile = "wetland-yumako"},
}

local GLEBA_NESTS = {
  {name = "gleba-spawner-small", weight = 75, tile = "wetland-yumako"},
  {name = "gleba-spawner", weight = 25, tile = "wetland-jellynut"},
}

local FULGORA_RUINS = {
  {name = "fulgoran-ruin-small", weight = 46, spacing = 10},
  {name = "fulgoran-ruin-medium", weight = 28, spacing = 14},
  {name = "fulgoran-ruin-stonehenge", weight = 12, spacing = 18},
  {name = "fulgoran-ruin-big", weight = 8, spacing = 22},
  {name = "fulgoran-ruin-huge", weight = 4, spacing = 30},
  {name = "fulgoran-ruin-colossal", weight = 2, spacing = 40},
}

local FULGORA_RUIN_NAMES = {
  "fulgoran-ruin-small", "fulgoran-ruin-medium", "fulgoran-ruin-stonehenge",
  "fulgoran-ruin-big", "fulgoran-ruin-huge", "fulgoran-ruin-colossal",
  "fulgoran-ruin-vault",
}

local VULCANUS_NATURALS = {
  {name = "big-volcanic-rock", weight = 74},
  {name = "huge-volcanic-rock", weight = 26},
}

local DEMOLISHERS = {
  easy = {"small-demolisher"},
  medium = {"medium-demolisher", "small-demolisher"},
  hard = {"medium-demolisher", "big-demolisher"},
  nightmare = {"big-demolisher", "medium-demolisher"},
}

local function active()
  local setting = settings.startup[SETTING_NAME]
  return script and script.active_mods and script.active_mods["space-age"]
    and setting and setting.value == "enabled"
end

local function exists(kind, name)
  return prototypes and prototypes[kind] and prototypes[kind][name] ~= nil
end

local function state()
  storage[STATE_KEY] = storage[STATE_KEY] or {
    version = GENERATION_VERSION,
    chunks = {},
    guaranteed_fulgora_vault = {},
  }
  local value = storage[STATE_KEY]
  value.version = GENERATION_VERSION
  value.chunks = value.chunks or {}
  value.guaranteed_fulgora_vault = value.guaranteed_fulgora_vault or {}
  return value
end

function M.region_at(x, y)
  if not active() then return "nauvis" end
  x, y = tonumber(x) or 0, tonumber(y) or 0
  if x * x + y * y < CENTRAL_RADIUS_SQUARED then return "nauvis" end
  local ax, ay = math.abs(x), math.abs(y)
  if ay >= ax then return y >= 0 and "gleba" or "aquilo" end
  return x < 0 and "vulcanus" or "fulgora"
end

local function valid_names(kind, names)
  local result = {}
  for _, name in ipairs(names or {}) do
    if exists(kind, name) then result[#result + 1] = name end
  end
  return result
end

local function weighted_pick(seed, x, y, stream, list)
  local total = 0
  for _, item in ipairs(list) do
    if exists("entity", item.name) then total = total + (item.weight or 1) end
  end
  if total <= 0 then return nil end
  local roll = hash.roll(seed, x, y, stream) * total
  local last_valid = nil
  for _, item in ipairs(list) do
    if exists("entity", item.name) then
      last_valid = item
      roll = roll - (item.weight or 1)
      if roll <= 0 then return item end
    end
  end
  return last_valid
end

local function is_liquid_name(name)
  name = name or ""
  return name == "out-of-map"
    or name:find("water", 1, true) ~= nil
    or name:find("ocean", 1, true) ~= nil
    or name:find("lava", 1, true) ~= nil
end

local function first_existing_tile(names, fallback)
  for _, name in ipairs(names or {}) do
    if exists("tile", name) then return name end
  end
  return fallback
end

local function regional_land_tile(region, seed, x, y, fallback)
  local palette = REGION_TILES[region]
  if not palette then return fallback end
  local available = {}
  for _, name in ipairs(palette) do
    if exists("tile", name) then available[#available + 1] = name end
  end
  if #available == 0 then return fallback end
  local bx, by = math.floor(x / 17), math.floor(y / 17)
  return available[hash.range(seed, bx, by, 30100, 1, #available)]
end

local function regional_liquid_tile(region, original, seed, x, y)
  local deep = original and original:find("deep", 1, true) ~= nil
  if region == "vulcanus" then
    return first_existing_tile({"lava"}, regional_land_tile(region, seed, x, y, original))
  elseif region == "fulgora" then
    return first_existing_tile(
      deep and {"oil-ocean-deep", "oil-ocean-shallow"} or {"oil-ocean-shallow", "oil-ocean-deep"},
      regional_land_tile(region, seed, x, y, original)
    )
  elseif region == "aquilo" then
    return first_existing_tile(
      deep and {"ammoniacal-ocean-2", "ammoniacal-ocean"} or {"ammoniacal-ocean", "ammoniacal-ocean-2"},
      regional_land_tile(region, seed, x, y, original)
    )
  elseif region == "gleba" then
    return first_existing_tile(
      deep and {"deepwater-green", "water-green", "wetland-jellynut"}
        or {"water-green", "wetland-yumako", "wetland-jellynut"},
      regional_land_tile(region, seed, x, y, original)
    )
  end
  return original
end

local function removable_natural(entity)
  if not (entity and entity.valid and entity.force and entity.force.valid) then return false end
  local force_name = entity.force.name
  if force_name ~= "neutral" and force_name ~= "enemy" then return false end
  return entity.type == "resource"
    or entity.type == "tree"
    or entity.type == "simple-entity"
    or entity.type == "simple-entity-with-owner"
    or entity.type == "cliff"
    or entity.type == "fish"
    or entity.type == "unit"
    or entity.type == "unit-spawner"
    or entity.type == "turret"
end

local function clear_original_nature(surface, area)
  for _, entity in pairs(surface.find_entities_filtered {area = area}) do
    if removable_natural(entity)
      and M.region_at(entity.position.x, entity.position.y) ~= "nauvis" then
      pcall(function() entity.destroy() end)
    end
  end
end

local function tile_accepts_entity(surface, x, y)
  local tile = surface.get_tile(x, y)
  return tile and tile.valid and not is_liquid_name(tile.name)
end

local function nearby(surface, names, x, y, radius, type_name)
  names = valid_names("entity", names)
  if #names == 0 then return false end
  local filter = {
    name = names,
    position = {x + 0.5, y + 0.5},
    radius = radius,
    limit = 1,
  }
  if type_name then filter.type = type_name end
  local found = surface.find_entities_filtered(filter)
  return found and #found > 0
end

local function resource_spacing_names(spec)
  if spec.spacing_names then return spec.spacing_names end
  return {spec.name}
end

local function place_natural(surface, name, x, y, force, search_radius)
  if not exists("entity", name) then return nil end
  local target = {x = x + 0.5, y = y + 0.5}
  local position = target
  local can_place = false
  pcall(function()
    can_place = surface.can_place_entity {name = name, position = target, force = force or "neutral"}
  end)
  if not can_place then
    local ok, found = pcall(function()
      return surface.find_non_colliding_position(name, target, search_radius or 4, 0.5, true)
    end)
    if not (ok and found) then return nil end
    if M.region_at(found.x, found.y) ~= M.region_at(x, y) then return nil end
    position = found
  end
  local ok, entity = pcall(function()
    return surface.create_entity {
      name = name,
      position = position,
      force = force or "neutral",
      raise_built = false,
    }
  end)
  return ok and entity and entity.valid and entity or nil
end

local function place_resource(surface, seed, x, y, spec, stream)
  if not (exists("entity", spec.name) and tile_accepts_entity(surface, x, y)) then return false end
  if (spec.min_spacing or 0) > 0
    and nearby(surface, resource_spacing_names(spec), x, y, spec.min_spacing, "resource") then
    return false
  end
  if #surface.find_entities_filtered {
    area = {{x, y}, {x + 1, y + 1}},
    type = "resource",
  } > 0 then return false end
  local amount = hash.range(seed, x, y, stream, spec.amount[1], spec.amount[2])
  local ok, entity = pcall(function()
    return surface.create_entity {
      name = spec.name,
      position = {x + 0.5, y + 0.5},
      amount = amount,
      force = "neutral",
    }
  end)
  return ok and entity and entity.valid or false
end

local function place_resource_or_natural(surface, seed, x, y, region, distance)
  local specs = RESOURCE_SETS[region]
  if not specs then return false end
  local width_multiplier = math.min(1 + distance / 350, 3.5) * 2
  for index, spec in ipairs(specs) do
    if exists("entity", spec.name) then
      local noise = Simplex.d2((x + 0.5) * TENDRIL_SCALE, (y + 0.5) * TENDRIL_SCALE,
        seed + spec.noise_seed)
      if math.abs(noise) < spec.width * width_multiplier then
        if spec.kind == "natural-entity" then
          if not nearby(surface, {spec.name}, x, y, spec.min_spacing or 0) then
            if spec.tile and exists("tile", spec.tile) then
              pcall(function()
                surface.set_tiles({{name = spec.tile, position = {x, y}}}, true, false, true, false)
              end)
            end
            if place_natural(surface, spec.name, x, y, "neutral", 5) then return true end
          end
        elseif place_resource(surface, seed, x, y, spec, 30200 + index) then
          return true
        end
      end
    end
  end
  return false
end

local function place_gleba_plant(surface, seed, x, y)
  if hash.roll(seed, x, y, 30300) > 0.22 then return false end
  local spec = weighted_pick(seed, x, y, 30301, GLEBA_PLANTS)
  if not spec then return false end
  if spec.tile and exists("tile", spec.tile) then
    pcall(function()
      surface.set_tiles({{name = spec.tile, position = {x, y}}}, true, false, true, false)
    end)
  end
  return place_natural(surface, spec.name, x, y, "neutral", 3) ~= nil
end

local function place_gleba_nest(surface, seed, x, y, distance)
  if x % 8 ~= 0 or y % 8 ~= 0 then return false end
  local chance = 0.05 + math.min(distance / 3500, 0.04)
  if hash.roll(seed, x, y, 30310) > chance then return false end
  local spec = weighted_pick(seed, x, y, 30311, GLEBA_NESTS)
  if not spec then return false end
  if spec.tile and exists("tile", spec.tile) then
    pcall(function()
      surface.set_tiles({{name = spec.tile, position = {x, y}}}, true, false, true, false)
    end)
  end
  return place_natural(surface, spec.name, x, y, "enemy", 4) ~= nil
end

local function place_vulcanus_environment(surface, seed, x, y)
  if hash.roll(seed, x, y, 30400) < 0.006 then
    local spec = weighted_pick(seed, x, y, 30401, VULCANUS_NATURALS)
    if spec and not nearby(surface, {"big-volcanic-rock", "huge-volcanic-rock"}, x, y, 6) then
      if place_natural(surface, spec.name, x, y, "neutral", 5) then return true end
    end
  end
  if hash.roll(seed, x, y, 30402) < 0.028 then
    local name = hash.roll(seed, x, y, 30403) < 0.85
      and "ashland-lichen-tree" or "ashland-lichen-tree-flaming"
    if place_natural(surface, name, x, y, "neutral", 3) then return true end
  end
  return false
end

local function place_fulgora_entity(surface, name, x, y, spacing, force, search_radius)
  if not exists("entity", name) or not tile_accepts_entity(surface, x, y) then return false end
  if spacing and spacing > 0 and nearby(surface, {name}, x, y, spacing) then return false end
  if nearby(surface, FULGORA_RUIN_NAMES, x, y, math.min(spacing or 0, 55))
    and name:find("fulgoran%-ruin") then return false end
  return place_natural(surface, name, x, y, force or "neutral", search_radius or 6) ~= nil
end

local function place_fulgora_environment(surface, seed, x, y)
  if hash.roll(seed, x, y, 30500) <= 0.00006
    and not nearby(surface, {"fulgoran-ruin-vault"}, x, y, 500) then
    if place_fulgora_entity(surface, "fulgoran-ruin-vault", x, y, 55, "neutral", 16) then return true end
  end
  if hash.roll(seed, x, y, 30501) <= 0.001
    and place_fulgora_entity(surface, "fulgoran-ruin-attractor", x, y, 90, "neutral", 8) then
    return true
  end
  if hash.roll(seed, x, y, 30502) <= 0.003
    and place_fulgora_entity(surface, "fulgurite", x, y, 27, "neutral", 6) then
    return true
  end
  if hash.roll(seed, x, y, 30503) <= 0.005 then
    local spec = weighted_pick(seed, x, y, 30504, FULGORA_RUINS)
    if spec and place_fulgora_entity(surface, spec.name, x, y, spec.spacing, "neutral", 10) then
      return true
    end
  end
  if hash.roll(seed, x, y, 30505) <= 0.0016
    and place_fulgora_entity(surface, "big-fulgora-rock", x, y, 18, "neutral", 6) then
    return true
  end
  return false
end

local function has_nearby_fulgora_oil(surface, x, y, radius)
  for _, name in ipairs({"oil-ocean-shallow", "oil-ocean-deep"}) do
    if exists("tile", name) then
      local found = surface.find_tiles_filtered {
        name = name,
        position = {x, y},
        radius = radius,
        limit = 1,
      }
      if found and #found > 0 then return true end
    end
  end
  return false
end

local function place_fulgora_oil_lake(surface, seed, chunk_position, area)
  if not exists("tile", "oil-ocean-shallow") then return false end
  local cx = math.floor((area.left_top.x + area.right_bottom.x) * 0.5)
  local cy = math.floor((area.left_top.y + area.right_bottom.y) * 0.5)
  if M.region_at(cx, cy) ~= "fulgora" then return false end
  if hash.roll(seed, chunk_position.x, chunk_position.y, 30520) > 0.18 then return false end
  if has_nearby_fulgora_oil(surface, cx, cy, 90) then return false end

  local rx = hash.range(seed, chunk_position.x, chunk_position.y, 30521, 5, 8)
  local ry = hash.range(seed, chunk_position.x, chunk_position.y, 30522, 4, 7)
  local lake_area = {{cx - rx - 1, cy - ry - 1}, {cx + rx + 2, cy + ry + 2}}
  for _, entity in pairs(surface.find_entities_filtered {area = lake_area}) do
    if removable_natural(entity) then pcall(function() entity.destroy() end) end
  end

  local tiles = {}
  for dx = -rx, rx do
    for dy = -ry, ry do
      local x, y = cx + dx, cy + dy
      local distance = (dx / rx) ^ 2 + (dy / ry) ^ 2
      if distance <= 1.05
        and M.region_at(x, y) == "fulgora"
        and hash.roll(seed, x, y, 30523) < 0.88 then
        local name = "oil-ocean-shallow"
        if exists("tile", "oil-ocean-deep") and distance < 0.35
          and hash.roll(seed, x, y, 30524) < 0.55 then
          name = "oil-ocean-deep"
        end
        tiles[#tiles + 1] = {name = name, position = {x, y}}
      end
    end
  end
  if #tiles == 0 then return false end
  surface.set_tiles(tiles, true, false, true, false)
  return true
end

local function danger_level(distance)
  if distance >= 2500 then return "nightmare" end
  if distance >= 2000 then return "hard" end
  if distance >= 1500 then return "medium" end
  return "easy"
end

local function place_vulcanus_demolisher(surface, seed, chunk_position, area)
  local cx = math.floor((area.left_top.x + area.right_bottom.x) * 0.5)
  local cy = math.floor((area.left_top.y + area.right_bottom.y) * 0.5)
  if M.region_at(cx, cy) ~= "vulcanus" then return false end
  local distance = math.sqrt(cx * cx + cy * cy)
  local chance = ({easy = 0.35, medium = 0.42, hard = 0.50, nightmare = 0.58})[danger_level(distance)]
  if hash.roll(seed, chunk_position.x, chunk_position.y, 30450) >= chance then return false end
  local names = valid_names("entity", {"small-demolisher", "medium-demolisher", "big-demolisher"})
  if #names == 0 or nearby(surface, names, cx, cy, 220) then return false end
  local preferred = DEMOLISHERS[danger_level(distance)] or DEMOLISHERS.easy
  local start = hash.range(seed, chunk_position.x, chunk_position.y, 30451, 1, #preferred)
  for offset = 0, #preferred - 1 do
    local name = preferred[((start + offset - 1) % #preferred) + 1]
    if exists("entity", name) then
      local position = surface.find_non_colliding_position(name, {cx + 0.5, cy + 0.5}, 14, 1, true)
      if position and M.region_at(position.x, position.y) == "vulcanus" then
        local ok, entity = pcall(function()
          return surface.create_entity {name = name, position = position, force = "enemy"}
        end)
        if ok and entity and entity.valid then return true end
      end
    end
  end
  return false
end

local function place_guaranteed_fulgora_vault(surface, area)
  if not exists("entity", "fulgoran-ruin-vault") then return false end
  -- Keep the guaranteed progression platform wholly inside one generated
  -- chunk so it never writes into a neighbouring ungenerated chunk.
  local anchor = {x = 1072, y = 16}
  if anchor.x < area.left_top.x or anchor.x >= area.right_bottom.x
    or anchor.y < area.left_top.y or anchor.y >= area.right_bottom.y then return false end
  local flags = state().guaranteed_fulgora_vault
  if flags[surface.index] then return false end

  local platform = first_existing_tile({"fulgoran-paving", "fulgoran-machinery", "fulgoran-sand"}, nil)
  local platform_area = {{anchor.x - 13, anchor.y - 13}, {anchor.x + 14, anchor.y + 14}}
  for _, entity in pairs(surface.find_entities_filtered {area = platform_area}) do
    if removable_natural(entity) then pcall(function() entity.destroy() end) end
  end
  if platform then
    local tiles = {}
    for x = anchor.x - 12, anchor.x + 12 do
      for y = anchor.y - 12, anchor.y + 12 do
        if M.region_at(x, y) == "fulgora" then
          tiles[#tiles + 1] = {name = platform, position = {x, y}}
        end
      end
    end
    surface.set_tiles(tiles, true, false, true, false)
  end
  local entity = place_natural(surface, "fulgoran-ruin-vault", anchor.x, anchor.y, "neutral", 10)
  if entity then
    flags[surface.index] = true
    return true
  end
  return false
end

local function convert_tiles(surface, area, seed)
  local tiles = {}
  for x = math.floor(area.left_top.x), math.ceil(area.right_bottom.x) - 1 do
    for y = math.floor(area.left_top.y), math.ceil(area.right_bottom.y) - 1 do
      local region = M.region_at(x + 0.5, y + 0.5)
      if region ~= "nauvis" then
        local current = surface.get_tile(x, y)
        local original = current and current.valid and current.name or "dirt-3"
        local name = is_liquid_name(original)
          and regional_liquid_tile(region, original, seed, x, y)
          or regional_land_tile(region, seed, x, y, original)
        if name and name ~= original then
          tiles[#tiles + 1] = {name = name, position = {x, y}}
        end
      end
    end
  end
  if #tiles > 0 then surface.set_tiles(tiles, true, false, true, false) end
  return #tiles
end

local function populate(surface, area, seed)
  for x = math.floor(area.left_top.x), math.ceil(area.right_bottom.x) - 1 do
    for y = math.floor(area.left_top.y), math.ceil(area.right_bottom.y) - 1 do
      local region = M.region_at(x + 0.5, y + 0.5)
      if region ~= "nauvis" and tile_accepts_entity(surface, x, y) then
        local distance = math.sqrt((x + 0.5) ^ 2 + (y + 0.5) ^ 2)
        local occupied = place_resource_or_natural(surface, seed, x, y, region, distance)
        if not occupied then
          if region == "gleba" then
            occupied = place_gleba_nest(surface, seed, x, y, distance)
            if not occupied then place_gleba_plant(surface, seed, x, y) end
          elseif region == "vulcanus" then
            place_vulcanus_environment(surface, seed, x, y)
          elseif region == "fulgora" then
            place_fulgora_environment(surface, seed, x, y)
          end
        end
      end
    end
  end
end

function M.on_chunk_generated(event)
  if not active() then return false end
  local surface = event and event.surface
  local position = event and event.position
  local area = event and event.area
  if not (surface and surface.valid and surface.name == "nauvis" and position and area) then return false end
  local key = tostring(surface.index) .. ":" .. tostring(position.x) .. ":" .. tostring(position.y)
  local value = state()
  if value.chunks[key] == GENERATION_VERSION then return false end

  local seed = tonumber(surface.map_gen_settings.seed) or 0
  clear_original_nature(surface, area)
  local changed = convert_tiles(surface, area, seed)
  if changed > 0 then
    place_fulgora_oil_lake(surface, seed, position, area)
    populate(surface, area, seed)
    place_vulcanus_demolisher(surface, seed, position, area)
    place_guaranteed_fulgora_vault(surface, area)
  end
  value.chunks[key] = GENERATION_VERSION
  return changed > 0
end

function M.on_init()
  if active() then state() end
end

function M.on_configuration_changed()
  if not active() then return end
  local value = state()
  for key in pairs(value.chunks) do
    local surface_index = tonumber(key:match("^(%d+):"))
    if surface_index and not game.surfaces[surface_index] then value.chunks[key] = nil end
  end
end

function M.on_gleba_nest_removed(entity, buffer)
  if not (active() and entity and entity.valid and entity.name
    and entity.name:find("gleba%-spawner")) then return false end
  if not (entity.surface and entity.surface.valid and entity.surface.name == "nauvis"
    and M.region_at(entity.position.x, entity.position.y) == "gleba") then return false end
  if not exists("item", "pentapod-egg") then return false end
  local surface = entity.surface
  local position = {x = entity.position.x, y = entity.position.y}
  local seed = tonumber(surface.map_gen_settings.seed) or 0
  local amount = hash.range(seed, math.floor(position.x), math.floor(position.y), 30320, 1, 4)
  local stack = {name = "pentapod-egg", count = amount}
  if buffer and buffer.valid then
    pcall(function() buffer.insert(stack) end)
  else
    pcall(function()
      surface.spill_item_stack {
        position = position,
        stack = stack,
        enable_looted = true,
        force = entity.force,
      }
    end)
  end
  return true
end

return M
