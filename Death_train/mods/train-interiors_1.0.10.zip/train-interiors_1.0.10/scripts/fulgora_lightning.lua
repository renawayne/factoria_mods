-- Localized Fulgora lightning for the shared directional Nauvis regions.
local hash = require("scripts.lib.hash")
local regions = require("scripts.everything_on_nauvis_regions")

local M = {}

local LIGHTNING_NAME = "lightning"
local UPDATE_INTERVAL = 120
local STORM_CELL_SIZE = 128
local MIN_STRIKE_DISTANCE = 8
local MAX_STRIKE_DISTANCE = 36
local REGION_SAFETY_MARGIN = 12
local MAX_TILE_CANDIDATES = 384
local STREAM_BASE = 3210
local WARNING_SPRITE = "utility/lightning_warning_icon"
local WARNING_SCALE = 0.55
local WARNING_OFFSET = {0, 0.65}
local MAX_ATTRACTOR_SEARCH_RADIUS = 64
local PROTECTION_EDGE_TOLERANCE = 0.25

local ATTRACTOR_BASE_RANGES = {
  ["lightning-rod"] = 15,
  ["lightning-collector"] = 25,
  ["fulgoran-ruin-attractor"] = 20,
}

local logged_surface_errors = {}

local function setting_enabled()
  local setting = settings.startup["the-cave-everything-on-nauvis"]
  return setting and setting.value == "enabled"
end

local function available()
  return setting_enabled()
    and script
    and script.active_mods
    and script.active_mods["space-age"] ~= nil
    and prototypes
    and prototypes.entity
    and prototypes.entity[LIGHTNING_NAME] ~= nil
end

local function safely_inside_fulgora(x, y)
  return regions.region_at(x, y) == "fulgora"
    and regions.region_at(x - REGION_SAFETY_MARGIN, y) == "fulgora"
    and regions.region_at(x + REGION_SAFETY_MARGIN, y) == "fulgora"
    and regions.region_at(x, y - REGION_SAFETY_MARGIN) == "fulgora"
    and regions.region_at(x, y + REGION_SAFETY_MARGIN) == "fulgora"
end

local function warning_store()
  storage.train_interiors_fulgora_lightning_warnings =
    storage.train_interiors_fulgora_lightning_warnings or {}
  return storage.train_interiors_fulgora_lightning_warnings
end

local function destroy_warning(player_index)
  local store = warning_store()
  local id = store[player_index]
  if not id then return end
  local object = rendering.get_object_by_id(id)
  if object then object.destroy() end
  store[player_index] = nil
end

local function player_in_fulgora(player)
  return player
    and player.valid
    and player.connected
    and player.surface
    and player.surface.valid
    and player.surface.name == "nauvis"
    and regions.region_at(math.floor(player.position.x), math.floor(player.position.y)) == "fulgora"
end

local function quality_range_multiplier(entity)
  local quality = entity and entity.quality
  local level = quality and quality.level or 0
  return 1 + 0.3 * level
end

local function protected(player)
  local attractors = player.surface.find_entities_filtered {
    position = player.position,
    radius = MAX_ATTRACTOR_SEARCH_RADIUS,
    type = "lightning-attractor",
  }
  for _, attractor in ipairs(attractors) do
    if attractor.valid then
      local base_range = ATTRACTOR_BASE_RANGES[attractor.name]
      if base_range then
        local radius = base_range * quality_range_multiplier(attractor) + PROTECTION_EDGE_TOLERANCE
        local dx = player.position.x - attractor.position.x
        local dy = player.position.y - attractor.position.y
        if dx * dx + dy * dy <= radius * radius then return true end
      end
    end
  end
  return false
end

function M.sync_warning_icons()
  local store = warning_store()
  local connected = {}
  for _, player in ipairs(game.connected_players) do
    connected[player.index] = true
    local target = player.character

    local is_inside_train = player.surface and string.find(player.surface.name, "train-interior")
    
    -- ЗАЩИТА ОТ КРАША: проверяем, что персонаж и игрок находятся на одной поверхности
    local same_surface = target and target.valid and target.surface == player.surface
    -- Проверяем, находится ли игрок в транспорте (поезде)
    local in_vehicle = player.vehicle ~= nil

    local should_show = available()
      and player_in_fulgora(player)
      and not protected(player)
      and target
      and target.valid
      and same_surface      -- Поверхности должны совпадать
      and not is_inside_train
      and not in_vehicle    -- Не рисуем иконку, если сидим в поезде

    local id = store[player.index]
    local object = id and rendering.get_object_by_id(id) or nil
    if should_show then
      if not object then
        local created = rendering.draw_sprite {
          sprite = WARNING_SPRITE,
          surface = player.surface,
          target = {type = "entity", entity = target, offset = WARNING_OFFSET},
          x_scale = WARNING_SCALE,
          y_scale = WARNING_SCALE,
          blink_interval = 30,
          render_layer = "arrow",
        }
        if created then store[player.index] = created.id end
      end
    elseif id then
      destroy_warning(player.index)
    end
  end

  local stale = {}
  for player_index in pairs(store) do
    if not connected[player_index] then stale[#stale + 1] = player_index end
  end
  for _, player_index in ipairs(stale) do destroy_warning(player_index) end
end

local function open_strike_tile(surface, x, y)
  local tile = surface.get_tile(x, y)
  return tile and tile.valid and tile.name ~= "out-of-map"
end

local function execute_strike(surface, anchor, cell_x, cell_y, tick)
  local seed = tonumber(surface.map_gen_settings.seed) or 0
  local cycle = math.floor(tick / UPDATE_INTERVAL)
  local candidates = surface.find_tiles_filtered {
    position = anchor,
    radius = MAX_STRIKE_DISTANCE,
    name = "out-of-map",
    invert = true,
    limit = MAX_TILE_CANDIDATES,
  }
  if not candidates or #candidates == 0 then return false end

  local start = hash.range(seed, cell_x + cycle * 31, cell_y - cycle * 17,
    STREAM_BASE, 1, #candidates)
  for offset = 0, #candidates - 1 do
    local tile = candidates[((start + offset - 1) % #candidates) + 1]
    local x, y = math.floor(tile.position.x), math.floor(tile.position.y)
    local dx, dy = (x + 0.5) - anchor.x, (y + 0.5) - anchor.y
    if dx * dx + dy * dy >= MIN_STRIKE_DISTANCE * MIN_STRIKE_DISTANCE
      and safely_inside_fulgora(x, y)
      and open_strike_tile(surface, x, y) then
      local ok, err = pcall(function()
        surface.execute_lightning {name = LIGHTNING_NAME, position = {x + 0.5, y + 0.5}}
      end)
      if not ok and not logged_surface_errors[surface.index] then
        logged_surface_errors[surface.index] = true
        log("[Train Interiors] Fulgora lightning failed on surface '"
          .. tostring(surface.name) .. "': " .. tostring(err))
      end
      return ok
    end
  end
  return false
end

function M.on_nth_tick(event)
  if not available() then return end
  local occupied, ordered = {}, {}
  for _, player in ipairs(game.connected_players) do
    if player_in_fulgora(player) then
      local cell_x = math.floor(player.position.x / STORM_CELL_SIZE)
      local cell_y = math.floor(player.position.y / STORM_CELL_SIZE)
      local key = player.surface.index .. ":" .. cell_x .. ":" .. cell_y
      if not occupied[key] then
        local cell = {
          surface = player.surface,
          anchor = {x = player.position.x, y = player.position.y},
          cell_x = cell_x,
          cell_y = cell_y,
        }
        occupied[key] = cell
        ordered[#ordered + 1] = cell
      end
    end
  end
  for _, cell in ipairs(ordered) do
    execute_strike(cell.surface, cell.anchor, cell.cell_x, cell.cell_y, event.tick)
  end
end

return M