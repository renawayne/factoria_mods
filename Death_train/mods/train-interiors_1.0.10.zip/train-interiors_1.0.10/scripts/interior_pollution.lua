-- Shared Train Interior and Locomotive Garden pollution venting.
-- Pollution belongs to one Factorio surface, so interior factories cannot
-- naturally affect enemies on the exterior Nauvis surface.
local M = {}

local POLLUTION_MULTIPLIER = 5
local DEBUG_ROOT = "train_interiors_pollution_debug"
local MAX_ATTACK_BUDGET = 400

local function valid_surface(surface)
  return surface and surface.valid
end

local function debug_root()
  storage[DEBUG_ROOT] = storage[DEBUG_ROOT] or {
    last_by_key = {},
    attack_budget_by_target = {},
  }
  local root = storage[DEBUG_ROOT]
  root.last_by_key = root.last_by_key or {}
  root.attack_budget_by_target = root.attack_budget_by_target or {}
  return root
end

local function target_unit_number(spec)
  local target = spec and spec.target_entity or nil
  if not (target and target.valid and target.unit_number) then return nil end
  return target.unit_number
end

local function remember_attack_pollution(spec, amount)
  amount = math.max(0, tonumber(amount) or 0)
  local unit_number = target_unit_number(spec)
  if amount <= 0 or not unit_number then return end
  local budgets = debug_root().attack_budget_by_target
  local value = budgets[unit_number]
  if type(value) ~= "table" then
    value = {amount = 0}
    budgets[unit_number] = value
  end
  value.amount = math.min(
    MAX_ATTACK_BUDGET,
    math.max(0, tonumber(value.amount) or 0) + amount
  )
  value.last_tick = game and game.tick or 0
end

local function remember_result(spec, source_amount, vented_amount, status)
  if not (storage and spec and spec.key) then return end
  local interior = spec.interior_surface
  local exterior = spec.exterior_surface
  local position = spec.position or {x = 0, y = 0}
  debug_root().last_by_key[spec.key] = {
    mode = spec.mode or "Interior",
    status = status or "unknown",
    source_amount = tonumber(source_amount) or 0,
    amount = tonumber(vented_amount) or 0,
    multiplier = POLLUTION_MULTIPLIER,
    tick = game and game.tick or 0,
    interior_surface = valid_surface(interior) and interior.name or "invalid",
    exterior_surface = valid_surface(exterior) and exterior.name or "invalid",
    x = tonumber(position.x or position[1]) or 0,
    y = tonumber(position.y or position[2]) or 0,
    target_unit_number = target_unit_number(spec),
  }
end

function M.clear(surface)
  if not valid_surface(surface) then return false end
  local ok = pcall(function() surface.clear_pollution() end)
  return ok == true
end

function M.transfer(spec)
  if not spec then return 0 end
  local interior = spec.interior_surface
  local exterior = spec.exterior_surface
  local position = spec.position
  if not (valid_surface(interior) and valid_surface(exterior) and position)
    or interior.index == exterior.index then
    remember_result(spec, 0, 0, "no-valid-exterior")
    return 0
  end

  local read_ok, amount = pcall(function() return interior.get_total_pollution() end)
  amount = read_ok and tonumber(amount) or 0
  if not amount or amount <= 0 then
    remember_result(spec, 0, 0, "idle")
    return 0
  end

  local vented_amount = amount * POLLUTION_MULTIPLIER
  local vent_ok = pcall(function() exterior.pollute(position, vented_amount) end)
  if not vent_ok then
    remember_result(spec, amount, 0, "vent-failed")
    return 0
  end

  local clear_ok = pcall(function() interior.clear_pollution() end)
  remember_attack_pollution(spec, vented_amount)
  remember_result(spec, amount, vented_amount, clear_ok and "transferred" or "clear-failed")
  return vented_amount
end

function M.attack_budget(target)
  if not (target and target.valid and target.unit_number) then return 0, nil end
  local value = debug_root().attack_budget_by_target[target.unit_number]
  if type(value) ~= "table" then return 0, nil end
  return math.max(0, tonumber(value.amount) or 0), tonumber(value.last_tick)
end

function M.consume_attack_budget(target, amount)
  if not (target and target.valid and target.unit_number) then return 0 end
  local value = debug_root().attack_budget_by_target[target.unit_number]
  if type(value) ~= "table" then return 0 end
  value.amount = math.max(0, (tonumber(value.amount) or 0) - math.max(0, tonumber(amount) or 0))
  return value.amount
end

function M.clear_attack_budgets()
  debug_root().attack_budget_by_target = {}
end

local function command_output(command, message)
  local player = command.player_index and game.get_player(command.player_index) or nil
  if player and player.valid then player.print(message) else game.print(message) end
end

function M.register_commands()
  commands.add_command(
    "the-cave-pollution-test",
    "Show the most recent Train Interior and Locomotive Garden pollution transfers.",
    function(command)
      local root = storage and storage[DEBUG_ROOT]
      local entries = root and root.last_by_key or nil
      if not entries or not next(entries) then
        command_output(command, "[Train Interiors] No interior pollution transfer cycle has run yet.")
        return
      end

      local keys = {}
      for key in pairs(entries) do keys[#keys + 1] = key end
      table.sort(keys)
      command_output(command, "[Train Interiors] Latest interior pollution transfer results:")
      for _, key in ipairs(keys) do
        local entry = entries[key]
        local age_seconds = math.max(0, ((game.tick or 0) - (entry.tick or 0)) / 60)
        local source_amount = tonumber(entry.source_amount) or 0
        local vented_amount = tonumber(entry.amount) or 0
        command_output(command, string.format(
          "  %s: collected %.2f, vented %.2f (x%.2f), %s -> %s at (%.1f, %.1f), status=%s, %.1fs ago",
          entry.mode or "Interior",
          source_amount,
          vented_amount,
          tonumber(entry.multiplier) or POLLUTION_MULTIPLIER,
          entry.interior_surface or "unknown",
          entry.exterior_surface or "unknown",
          tonumber(entry.x) or 0,
          tonumber(entry.y) or 0,
          entry.status or "unknown",
          age_seconds
        ))
      end
    end
  )
end

return M
