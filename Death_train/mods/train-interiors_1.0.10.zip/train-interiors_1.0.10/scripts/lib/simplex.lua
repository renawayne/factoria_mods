-- 2D simplex noise, ported from RedMew's GPL-3.0 Diggy implementation.
local Simplex = {}

local grad3 = {
  {1, 1}, {-1, 1}, {1, -1}, {-1, -1},
  {1, 0}, {-1, 0}, {1, 0}, {-1, 0},
  {0, 1}, {0, -1}, {0, 1}, {0, -1},
}

local p = {
  151,160,137,91,90,15,131,13,201,95,96,53,194,233,7,225,
  140,36,103,30,69,142,8,99,37,240,21,10,23,190,6,148,
  247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,
  57,177,33,88,237,149,56,87,174,20,125,136,171,168,68,175,
  74,165,71,134,139,48,27,166,77,146,158,231,83,111,229,122,
  60,211,133,230,220,105,92,41,55,46,245,40,244,102,143,54,
  65,25,63,161,1,216,80,73,209,76,132,187,208,89,18,169,
  200,196,135,130,116,188,159,86,164,100,109,198,173,186,3,64,
  52,217,226,250,124,123,5,202,38,147,118,126,255,82,85,212,
  207,206,59,227,47,16,58,17,182,189,28,42,223,183,170,213,
  119,248,152,2,44,154,163,70,221,153,101,155,167,43,172,9,
  129,22,39,253,19,98,108,110,79,113,224,232,178,185,112,104,
  218,246,97,228,251,34,242,193,238,210,144,12,191,179,162,241,
  81,51,145,235,249,14,239,107,49,192,214,31,181,199,106,157,
  184,84,204,176,115,121,50,45,127,4,150,254,138,236,205,93,
  222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180,
}

local perm = {}
for i = 0, 511 do perm[i + 1] = p[bit32.band(i, 255) + 1] end

local floor, band = math.floor, bit32.band
local F2 = 0.5 * (math.sqrt(3) - 1)
local G2 = (3 - math.sqrt(3)) / 6

function Simplex.d2(xin, yin, seed)
  xin = xin + seed
  yin = yin + seed
  local s = (xin + yin) * F2
  local i = floor(xin + s)
  local j = floor(yin + s)
  local t = (i + j) * G2
  local x0 = xin - (i - t)
  local y0 = yin - (j - t)
  local i1, j1
  if x0 > y0 then i1, j1 = 1, 0 else i1, j1 = 0, 1 end
  local x1, y1 = x0 - i1 + G2, y0 - j1 + G2
  local x2, y2 = x0 - 1 + 2 * G2, y0 - 1 + 2 * G2
  local ii, jj = band(i, 255), band(j, 255)
  local gi0 = perm[ii + perm[jj + 1] + 1] % 12
  local gi1 = perm[ii + i1 + perm[jj + j1 + 1] + 1] % 12
  local gi2 = perm[ii + 1 + perm[jj + 2] + 1] % 12

  local function contribution(value, gx, gy, gradient)
    if value < 0 then return 0 end
    value = value * value
    local g = grad3[gradient + 1]
    return value * value * (g[1] * gx + g[2] * gy)
  end

  return 70 * (
    contribution(0.5 - x0 * x0 - y0 * y0, x0, y0, gi0)
    + contribution(0.5 - x1 * x1 - y1 * y1, x1, y1, gi1)
    + contribution(0.5 - x2 * x2 - y2 * y2, x2, y2, gi2)
  )
end

return Simplex
