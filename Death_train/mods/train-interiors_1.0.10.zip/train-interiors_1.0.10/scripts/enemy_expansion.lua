-- Reliable dense enemy expansion for ordinary Nauvis.
-- Factorio's build_enemy_base command is asynchronous, so a successful Lua
-- call does not mean that a migration ever arrived or built a nest. This
-- controller places one confirmed nest at each Evolution-scaled interval and
-- leaves the native expansion planner enabled for normal additional growth.
local hash = require("scripts.lib.hash")
local train_interiors = require("scripts.train_interiors")

local M = {}

local STORAGE_KEY = "train_interiors_enemy_expansion"
local TARGET_STREAM = 278700
local SPAWNER_STREAM = 278701
local CHECK_INTERVAL = 300
local TICKS_PER_MINUTE = 60 * 60
local MAX_EXPANSION_COOLDOWN = 10 * TICKS_PER_MINUTE
local MIN_EXPANSION_COOLDOWN = 2 * TICKS_PER_MINUTE
local FAILED_RETRY_COOLDOWN = 30 * 60
local ACTIVE_SOURCE_LIMIT = 24
local PLAYER_SAFE_RADIUS_CHUNKS = 3
local ATTACK_POLLUTION_CONSUMPTION_MODIFIER = 0.1
local NORMAL_ATTACK_POLLUTION_CONSUMPTION_MODIFIER = 1.0
local TRAIN_ATTACK_COOLDOWN = 60 * 60
local TRAIN_ATTACK_FAILED_RETRY = 15 * 60
local TRAIN_ATTACK_SEARCH_DISTANCE = 2048
local TRAIN_ATTACK_POLLUTION_PER_UNIT = 4
local TRAIN_ATTACK_MIN_GROUP_SIZE = 5
local TRAIN_ATTACK_MAX_GROUP_SIZE = 20

local function setting_enabled()
  local setting = settings.startup["the-cave-allow-biter-expansion"]
  return not setting or setting.value == "enabled" or setting.value == true
end

local function main_nauvis_surface(surface)
  return surface and surface.valid and surface.name == "nauvis"
end

local function root()
  local value = storage[STORAGE_KEY]
  if type(value) ~= "table" then
    value = {version = 3, surfaces = {}, attack_targets = {}}
    storage[STORAGE_KEY] = value
  end
  value.version = 3
  value.surfaces = value.surfaces or {}
  value.attack_targets = value.attack_targets or {}
  return value
end

local function state_for(surface)
  local states = root().surfaces
  local value = states[surface.index]
  if type(value) ~= "table" then
    value = {
      sequence = 0,
      next_tick = nil,
      successful_expansions = 0,
      last_attempt_result = "never",
    }
    states[surface.index] = value
  end
  value.sequence = math.max(0, math.floor(tonumber(value.sequence) or 0))
  value.successful_expansions = math.max(
    0,
    math.floor(tonumber(value.successful_expansions) or 0)
  )
  value.last_attempt_result = value.last_attempt_result or "never"
  return value
end

local function apply_map_settings()
  local expansion = game and game.map_settings and game.map_settings.enemy_expansion
  if not expansion then return false end
  -- The startup option controls whether expansion is allowed, but the map's
  -- native cooldown, distance and group-size choices remain authoritative.
  expansion.enabled = setting_enabled()
  return true
end

local function apply_attack_pollution_cost()
  local pollution = game and game.map_settings and game.map_settings.pollution
  if not pollution then return false end
  pollution.enemy_attack_pollution_consumption_modifier = setting_enabled()
    and ATTACK_POLLUTION_CONSUMPTION_MODIFIER
    or NORMAL_ATTACK_POLLUTION_CONSUMPTION_MODIFIER
  return true
end

local function evolution_for(surface)
  local enemy = game and game.forces and game.forces.enemy or nil
  if not (enemy and enemy.valid) then return 0 end
  local ok, value = pcall(function() return enemy.get_evolution_factor(surface) end)
  if not ok then value = enemy.evolution_factor end
  return math.max(0, math.min(1, tonumber(value) or 0))
end

-- Ten minutes at zero Evolution, eight at 25 percent, six at 50 percent,
-- four at 75 percent and two at full Evolution.
local function expansion_cooldown(surface)
  local evolution = evolution_for(surface)
  return math.max(1, math.floor(
    MAX_EXPANSION_COOLDOWN
      - evolution * (MAX_EXPANSION_COOLDOWN - MIN_EXPANSION_COOLDOWN)
      + 0.5
  ))
end

local function chunk_key(x, y)
  return tostring(x) .. ":" .. tostring(y)
end

local function add_chunk_count(counts, position)
  local x = math.floor(position.x / 32)
  local y = math.floor(position.y / 32)
  local key = chunk_key(x, y)
  counts[key] = (counts[key] or 0) + 1
end

local function enemy_spawners(surface)
  return surface.find_entities_filtered {
    type = "unit-spawner",
    force = "enemy",
  }
end

local function active_anchor_positions(surface)
  local positions = {}
  for _, player in pairs(game.connected_players or {}) do
    if player.valid and player.surface == surface then
      positions[#positions + 1] = {x = player.position.x, y = player.position.y}
    end
  end
  return positions
end

local function nearest_anchor_distance_squared(position, anchors)
  if #anchors == 0 then return 0 end
  local nearest = math.huge
  for _, anchor in ipairs(anchors) do
    local dx = position.x - anchor.x
    local dy = position.y - anchor.y
    nearest = math.min(nearest, dx * dx + dy * dy)
  end
  return nearest
end

-- Prefer nests nearest to active Nauvis players. This avoids the Factorio 2.0
-- problem where expansion attempts are diluted across the entire explored map.
local function prioritized_spawners(surface, spawners)
  local anchors = active_anchor_positions(surface)
  local ranked = {}
  for _, entity in pairs(spawners) do
    if entity.valid then
      ranked[#ranked + 1] = {
        entity = entity,
        distance = nearest_anchor_distance_squared(entity.position, anchors),
      }
    end
  end
  table.sort(ranked, function(a, b)
    if a.distance == b.distance then
      return (a.entity.unit_number or 0) < (b.entity.unit_number or 0)
    end
    return a.distance < b.distance
  end)

  local selected = {}
  for index = 1, math.min(#ranked, ACTIVE_SOURCE_LIMIT) do
    selected[#selected + 1] = ranked[index].entity
  end
  return selected
end

local function player_building_counts(surface)
  local counts = {}
  for _, force in pairs(game.forces) do
    if force.valid and force.name ~= "enemy" and force.name ~= "neutral" then
      for _, entity in pairs(surface.find_entities_filtered {force = force}) do
        if entity.valid and entity.prototype and entity.prototype.is_building then
          add_chunk_count(counts, entity.position)
        end
      end
    end
  end
  return counts
end

local function influence(counts, center_x, center_y, radius, coefficient)
  local total = 0
  radius = math.max(0, math.floor(tonumber(radius) or 0))
  coefficient = tonumber(coefficient) or 0
  for dx = -radius, radius do
    for dy = -radius, radius do
      local count = counts[chunk_key(center_x + dx, center_y + dy)] or 0
      if count > 0 then
        total = total + count * (coefficient ^ (math.abs(dx) + math.abs(dy)))
      end
    end
  end
  return total
end

local function candidate_score(candidate, player_counts, expansion)
  -- Direct placement must never appear inside or immediately beside a factory.
  if influence(
    player_counts,
    candidate.x,
    candidate.y,
    PLAYER_SAFE_RADIUS_CHUNKS,
    1
  ) > 0 then
    return 0
  end

  local player = influence(
    player_counts,
    candidate.x,
    candidate.y,
    expansion.enemy_building_influence_radius,
    expansion.neighbouring_chunk_coefficient
  ) * (tonumber(expansion.building_coefficient) or 0.1)
  return 1 / (1 + player)
end

local function candidate_position(surface, chunk_x, chunk_y)
  local left = chunk_x * 32
  local top = chunk_y * 32
  local position = surface.find_non_colliding_position_in_box(
    "biter-spawner",
    {{left + 3, top + 3}, {left + 29, top + 29}},
    1,
    true
  )
  if not position then return nil end
  local tile = surface.get_tile(position)
  if not (tile and tile.valid) or tile.name == "out-of-map" then return nil end
  return {x = position.x, y = position.y}
end

local function collect_candidates(surface, spawners, expansion)
  local maximum_distance = math.max(
    0,
    math.floor(tonumber(expansion.max_expansion_distance) or 7)
  )
  if maximum_distance <= 0 then return {} end

  local by_key = {}
  local maximum_squared = maximum_distance * maximum_distance
  for _, spawner in pairs(spawners) do
    if spawner.valid then
      local source_x = math.floor(spawner.position.x / 32)
      local source_y = math.floor(spawner.position.y / 32)
      for dx = -maximum_distance, maximum_distance do
        for dy = -maximum_distance, maximum_distance do
          if dx * dx + dy * dy <= maximum_squared then
            local x = source_x + dx
            local y = source_y + dy
            local key = chunk_key(x, y)
            if not by_key[key] and surface.is_chunk_generated {x, y} then
              by_key[key] = {x = x, y = y}
            end
          end
        end
      end
    end
  end

  local candidates = {}
  for _, candidate in pairs(by_key) do candidates[#candidates + 1] = candidate end
  table.sort(candidates, function(a, b)
    if a.y == b.y then return a.x < b.x end
    return a.y < b.y
  end)

  local eligible = {}
  for _, candidate in ipairs(candidates) do
    local position = candidate_position(surface, candidate.x, candidate.y)
    if position then
      candidate.position = position
      eligible[#eligible + 1] = candidate
    end
  end
  return eligible
end

local function choose_candidate(surface, state, candidates, expansion)
  if #candidates == 0 then return nil, 0 end
  local player_counts = player_building_counts(surface)
  local total = 0
  local eligible_count = 0
  for _, candidate in ipairs(candidates) do
    candidate.score = candidate_score(candidate, player_counts, expansion)
    if candidate.score > 0 then eligible_count = eligible_count + 1 end
    total = total + candidate.score
  end
  if total <= 0 then return nil, eligible_count end

  local seed = tonumber(surface.map_gen_settings.seed) or 0
  local roll = hash.roll(seed, surface.index, state.sequence, TARGET_STREAM) * total
  local accumulated = 0
  for _, candidate in ipairs(candidates) do
    accumulated = accumulated + candidate.score
    if candidate.score > 0 and roll < accumulated then return candidate, eligible_count end
  end
  for index = #candidates, 1, -1 do
    if candidates[index].score > 0 then return candidates[index], eligible_count end
  end
  return nil, eligible_count
end

local function spawner_name(surface, state, target)
  local seed = tonumber(surface.map_gen_settings.seed) or 0
  local roll = hash.roll(
    seed,
    target.x + state.sequence,
    target.y,
    SPAWNER_STREAM
  )
  return roll < 0.5 and "biter-spawner" or "spitter-spawner"
end

local function record_failure(state, result, source_count, candidate_count)
  state.last_attempt_result = result
  state.last_source_count = source_count or 0
  state.last_candidate_count = candidate_count or 0
  state.last_attempt_tick = game.tick
  return false
end

local function attempt_expansion(surface, state)
  if surface.no_enemies_mode then
    return record_failure(state, "No Enemies mode is enabled", 0, 0)
  end

  local expansion = game.map_settings.enemy_expansion
  local all_spawners = enemy_spawners(surface)
  if #all_spawners == 0 then
    return record_failure(state, "no source nests", 0, 0)
  end

  local sources = prioritized_spawners(surface, all_spawners)
  local candidates = collect_candidates(surface, sources, expansion)
  local target, eligible_count = choose_candidate(surface, state, candidates, expansion)
  if not target then
    return record_failure(state, "no safe generated target", #sources, eligible_count)
  end

  local chosen_name = spawner_name(surface, state, target)
  local alternate_name = chosen_name == "biter-spawner"
    and "spitter-spawner"
    or "biter-spawner"
  local entity
  local ok = pcall(function()
    entity = surface.create_entity {
      name = chosen_name,
      position = target.position,
      force = game.forces.enemy,
    }
  end)
  if not ok or not (entity and entity.valid) then
    entity = nil
    pcall(function()
      entity = surface.create_entity {
        name = alternate_name,
        position = target.position,
        force = game.forces.enemy,
      }
    end)
  end
  if not (entity and entity.valid) then
    return record_failure(state, "placement failed", #sources, eligible_count)
  end

  pcall(function() script.raise_biter_base_built {entity = entity} end)
  if not entity.valid then
    return record_failure(state, "nest removed by another script", #sources, eligible_count)
  end

  state.successful_expansions = state.successful_expansions + 1
  state.last_attempt_result = string.format(
    "built %s at %.1f, %.1f",
    entity.name,
    entity.position.x,
    entity.position.y
  )
  state.last_source_count = #sources
  state.last_candidate_count = eligible_count
  state.last_attempt_tick = game.tick
  state.last_built_position = {x = entity.position.x, y = entity.position.y}
  return true
end

local function schedule_next(surface, state, tick, succeeded)
  local cooldown = succeeded == false
    and FAILED_RETRY_COOLDOWN
    or expansion_cooldown(surface)
  state.next_tick = tick + cooldown
end

local function main_surfaces()
  local surfaces = {}
  for _, surface in pairs(game.surfaces) do
    if main_nauvis_surface(surface) then surfaces[#surfaces + 1] = surface end
  end
  table.sort(surfaces, function(a, b) return a.index < b.index end)
  return surfaces
end

local function command_print(command, message)
  local player = command.player_index and game.get_player(command.player_index) or nil
  if player and player.valid then player.print(message) else game.print(message) end
end

local function expansion_enabled()
  local expansion = game.map_settings and game.map_settings.enemy_expansion
  return setting_enabled() and expansion and expansion.enabled == true or false
end

local function main_locomotives()
  local by_unit = {}
  for _, force in pairs(game.forces or {}) do
    if force.valid and force.name ~= "enemy" and force.name ~= "neutral" then
      local ok, wagon = pcall(function()
        return train_interiors._garden_main_locomotive_wagon(force)
      end)
      local target = ok and wagon and wagon.entity or nil
      if target and target.valid and target.unit_number
        and main_nauvis_surface(target.surface) then
        by_unit[target.unit_number] = target
      end
    end
  end

  local targets = {}
  for _, target in pairs(by_unit) do targets[#targets + 1] = target end
  table.sort(targets, function(a, b)
    return (a.unit_number or math.huge) < (b.unit_number or math.huge)
  end)
  return targets
end

local function attack_state_for(target)
  local states = root().attack_targets
  local key = target and target.unit_number or nil
  if not key then return nil end
  local value = states[key]
  if type(value) ~= "table" then
    value = {
      next_tick = nil,
      last_result = "never",
      last_sent = 0,
    }
    states[key] = value
  end
  value.last_result = value.last_result or "never"
  value.last_sent = math.max(0, math.floor(tonumber(value.last_sent) or 0))
  return value
end

local function attack_remaining_text(state)
  if not (state and tonumber(state.next_tick)) then return "not scheduled" end
  return tostring(math.max(0, math.ceil((state.next_tick - game.tick) / 60))) .. " seconds"
end

local function enemy_cease_fire(target)
  local enemy = game.forces and game.forces.enemy or nil
  local target_force = target and target.force or nil
  if not (enemy and enemy.valid and target_force and target_force.valid) then return false end
  local enemy_ok, enemy_value = pcall(function() return enemy.get_cease_fire(target_force) end)
  local target_ok, target_value = pcall(function() return target_force.get_cease_fire(enemy) end)
  return enemy_ok and enemy_value == true or target_ok and target_value == true or false
end

local function polluted_nests_near(target)
  local surface = target and target.surface or nil
  if not (surface and surface.valid) then return {}, 0 end
  local ok, spawners = pcall(function()
    return surface.find_entities_filtered {
      position = target.position,
      radius = TRAIN_ATTACK_SEARCH_DISTANCE,
      type = "unit-spawner",
      force = "enemy",
    }
  end)
  if not ok or type(spawners) ~= "table" then return {}, 0 end

  local polluted = {}
  local highest = 0
  for _, spawner in pairs(spawners) do
    if spawner.valid then
      local pollution_ok, amount = pcall(function()
        return surface.get_pollution(spawner.position)
      end)
      amount = pollution_ok and math.max(0, tonumber(amount) or 0) or 0
      if amount > 0 then
        polluted[#polluted + 1] = {entity = spawner, pollution = amount}
        highest = math.max(highest, amount)
      end
    end
  end
  table.sort(polluted, function(a, b)
    if a.pollution == b.pollution then
      return (a.entity.unit_number or math.huge) < (b.entity.unit_number or math.huge)
    end
    return a.pollution > b.pollution
  end)
  return polluted, highest
end

local function attack_group_size(surface, budget)
  local evolution_cap = math.floor(
    TRAIN_ATTACK_MIN_GROUP_SIZE
      + evolution_for(surface) * (TRAIN_ATTACK_MAX_GROUP_SIZE - TRAIN_ATTACK_MIN_GROUP_SIZE)
      + 0.5
  )
  local affordable = math.floor(
    math.max(0, tonumber(budget) or 0) / TRAIN_ATTACK_POLLUTION_PER_UNIT
  )
  if affordable < TRAIN_ATTACK_MIN_GROUP_SIZE then return 0 end
  return math.min(TRAIN_ATTACK_MAX_GROUP_SIZE, evolution_cap, affordable)
end

local function record_attack_failure(state, result, details)
  state.last_result = result
  state.last_sent = 0
  state.last_existing_sent = 0
  state.last_spawned_sent = 0
  state.last_attempt_tick = game.tick
  state.next_tick = game.tick + TRAIN_ATTACK_FAILED_RETRY
  if details then
    for key, value in pairs(details) do state[key] = value end
  end
  return false, 0, result
end

local function attack_unit_name(surface, index)
  local evolution = evolution_for(surface)
  local tier = "small"
  if evolution >= 0.85 then
    tier = "behemoth"
  elseif evolution >= 0.50 then
    tier = "big"
  elseif evolution >= 0.20 then
    tier = "medium"
  end
  local kind = index % 4 == 0 and "spitter" or "biter"
  return tier .. "-" .. kind
end

local function command_unit_to_target(unit, target)
  if not (unit and unit.valid and target and target.valid and unit.surface == target.surface) then
    return false
  end
  local command = {
    type = defines.command.attack,
    target = target,
    distraction = defines.distraction.by_enemy,
  }
  local commanded = false
  pcall(function()
    if unit.commandable and unit.commandable.valid then
      unit.commandable.set_command(command)
      commanded = true
    end
  end)
  if not commanded then
    pcall(function()
      if unit.set_command then
        unit.set_command(command)
        commanded = true
      end
    end)
  end
  return commanded
end

local function create_and_command_unit(target, polluted_nest, index)
  local surface = target.surface
  local name = attack_unit_name(surface, index)
  local position
  local position_ok = pcall(function()
    position = surface.find_non_colliding_position(
      name,
      polluted_nest.entity.position,
      20,
      1,
      true
    )
  end)
  if not position_ok or not position then return false end

  local unit
  local create_ok = pcall(function()
    unit = surface.create_entity {
      name = name,
      position = position,
      force = game.forces.enemy,
      create_build_effect_smoke = false,
    }
  end)
  if not create_ok or not (unit and unit.valid) then return false end
  pcall(function()
    if unit.ai_settings then unit.ai_settings.allow_destroy_when_commands_fail = false end
  end)
  if command_unit_to_target(unit, target) then return true end
  pcall(function() unit.destroy() end)
  return false
end

local function dispatch_train_attack(target, state)
  if not expansion_enabled() then
    return record_attack_failure(state, "Allow Biter Expansion is disabled")
  end
  if not (target and target.valid and target.unit_number and main_nauvis_surface(target.surface)) then
    return record_attack_failure(state, "Main Locomotive target is unavailable")
  end

  local surface = target.surface
  local pollution = game.map_settings and game.map_settings.pollution or nil
  if not (pollution and pollution.enabled) then
    return record_attack_failure(state, "pollution is disabled")
  end
  if surface.no_enemies_mode then
    return record_attack_failure(state, "No Enemies mode is enabled")
  end
  if surface.peaceful_mode then
    return record_attack_failure(state, "Peaceful mode is enabled")
  end
  if enemy_cease_fire(target) then
    return record_attack_failure(state, "enemy cease fire is enabled")
  end

  local destructible_ok, destructible = pcall(function() return target.destructible end)
  if destructible_ok and destructible == false then
    return record_attack_failure(state, "Main Locomotive is not destructible")
  end

  local budget = train_interiors.interior_pollution.attack_budget(target)
  local desired = attack_group_size(surface, budget)
  if desired <= 0 then
    return record_attack_failure(state, string.format(
      "not enough new train pollution: %.1f of %.1f required",
      budget,
      TRAIN_ATTACK_MIN_GROUP_SIZE * TRAIN_ATTACK_POLLUTION_PER_UNIT
    ), {last_budget_before = budget, last_budget_after = budget})
  end

  local nests, highest = polluted_nests_near(target)
  if #nests == 0 then
    return record_attack_failure(state, "no polluted enemy nest within 2048 tiles", {
      last_budget_before = budget,
      last_budget_after = budget,
      last_polluted_nests = 0,
      last_highest_nest_pollution = 0,
    })
  end

  local existing_sent = 0
  local multi_ok, multi_result = pcall(function()
    return surface.set_multi_command {
      command = {
        type = defines.command.attack,
        target = target,
        distraction = defines.distraction.by_enemy,
      },
      unit_count = desired,
      force = game.forces.enemy,
      unit_search_distance = TRAIN_ATTACK_SEARCH_DISTANCE,
    }
  end)
  if multi_ok then
    existing_sent = math.min(desired, math.max(0, math.floor(tonumber(multi_result) or 0)))
  end

  -- Native attack groups are preferred. If Factorio has no idle units ready,
  -- create the missing attackers beside genuinely polluted nests, as The Cave
  -- wave controller does, and give every unit the moving locomotive target.
  local spawned_sent = 0
  for index = existing_sent + 1, desired do
    local nest = nests[((index - existing_sent - 1) % #nests) + 1]
    if create_and_command_unit(target, nest, index) then
      spawned_sent = spawned_sent + 1
    end
  end

  local total_sent = existing_sent + spawned_sent
  if total_sent <= 0 then
    local result = multi_ok
      and "no available enemy units and unit creation failed"
      or "enemy command failed and unit creation failed"
    return record_attack_failure(state, result, {
      last_budget_before = budget,
      last_budget_after = budget,
      last_polluted_nests = #nests,
      last_highest_nest_pollution = highest,
    })
  end

  local remaining_budget = train_interiors.interior_pollution.consume_attack_budget(
    target,
    total_sent * TRAIN_ATTACK_POLLUTION_PER_UNIT
  )
  state.last_result = string.format(
    "sent %d enemies to Main Locomotive (%d existing, %d created)",
    total_sent,
    existing_sent,
    spawned_sent
  )
  state.last_sent = total_sent
  state.last_existing_sent = existing_sent
  state.last_spawned_sent = spawned_sent
  state.last_attempt_tick = game.tick
  state.last_budget_before = budget
  state.last_budget_after = remaining_budget
  state.last_polluted_nests = #nests
  state.last_highest_nest_pollution = highest
  state.next_tick = game.tick + TRAIN_ATTACK_COOLDOWN
  return true, total_sent, state.last_result
end

local function prune_attack_states(live_targets)
  local live = {}
  for _, target in ipairs(live_targets) do live[target.unit_number] = true end
  for unit_number in pairs(root().attack_targets) do
    if not live[unit_number] then root().attack_targets[unit_number] = nil end
  end
end

local function remaining_text(state)
  if not (state and tonumber(state.next_tick)) then return "not scheduled" end
  return tostring(math.max(0, math.ceil((state.next_tick - game.tick) / 60))) .. " seconds"
end

local function polluted_nest_status(surface, spawners)
  local polluted = 0
  local highest = 0
  for _, spawner in pairs(spawners) do
    if spawner.valid then
      local ok, amount = pcall(function() return surface.get_pollution(spawner.position) end)
      amount = ok and tonumber(amount) or 0
      if amount > 0 then polluted = polluted + 1 end
      highest = math.max(highest, amount)
    end
  end
  return polluted, highest
end

local function test_status(command, surfaces)
  local pollution = game.map_settings and game.map_settings.pollution or nil
  for _, surface in ipairs(surfaces) do
    local value = state_for(surface)
    local spawners = enemy_spawners(surface)
    local polluted, highest = polluted_nest_status(surface, spawners)
    command_print(command, string.format(
      "[Train Interiors] %s: Evolution %.1f%% | Enemy nests: %d | Confirmed custom nests: %d | Last attempt: %s | Sources: %d | Safe targets: %d | Next attempt: %s | Expansion: %s.",
      surface.name,
      evolution_for(surface) * 100,
      #spawners,
      value.successful_expansions,
      value.last_attempt_result,
      tonumber(value.last_source_count) or 0,
      tonumber(value.last_candidate_count) or 0,
      remaining_text(value),
      expansion_enabled() and "enabled" or "disabled"
    ))
    command_print(command, string.format(
      "[Train Interiors] Pollution: %s | Polluted nests: %d of %d | Highest nest pollution: %.1f | Peaceful mode: %s | No Enemies mode: %s | Attack cost: %.2f.",
      pollution and pollution.enabled and "enabled" or "disabled",
      polluted,
      #spawners,
      highest,
      surface.peaceful_mode and "enabled" or "disabled",
      surface.no_enemies_mode and "enabled" or "disabled",
      pollution and tonumber(pollution.enemy_attack_pollution_consumption_modifier) or 0
    ))
  end

  local targets = main_locomotives()
  if #targets == 0 then
    command_print(command, "[Train Interiors] Main Locomotive attack target: unavailable.")
    return
  end
  for _, target in ipairs(targets) do
    local value = attack_state_for(target)
    local budget, last_pollution_tick = train_interiors.interior_pollution.attack_budget(target)
    local nests, highest = polluted_nests_near(target)
    local target_pollution = 0
    pcall(function() target_pollution = target.surface.get_pollution(target.position) end)
    local pollution_age = last_pollution_tick
      and tostring(math.max(0, math.ceil((game.tick - last_pollution_tick) / 60))) .. " seconds ago"
      or "never"
    command_print(command, string.format(
      "[Train Interiors] Main Locomotive #%d attack target: Train pollution %.1f | Last train pollution: %s | Pollution at train: %.1f | Polluted nests within 2048 tiles: %d | Highest nest pollution: %.1f | Last sent: %d | Last result: %s | Next attack: %s.",
      target.unit_number,
      budget,
      pollution_age,
      tonumber(target_pollution) or 0,
      #nests,
      highest,
      value.last_sent,
      value.last_result,
      attack_remaining_text(value)
    ))
  end
end

local function run_immediate_test(command, surfaces)
  if not expansion_enabled() then
    command_print(command, "[Train Interiors] Allow Biter Expansion is currently disabled.")
    return
  end
  for _, surface in ipairs(surfaces) do
    local value = state_for(surface)
    local before = surface.count_entities_filtered {type = "unit-spawner", force = "enemy"}
    value.sequence = value.sequence + 1
    local succeeded = attempt_expansion(surface, value)
    schedule_next(surface, value, game.tick, succeeded)
    local after = surface.count_entities_filtered {type = "unit-spawner", force = "enemy"}
    command_print(command, string.format(
      "[Train Interiors] %s: Immediate Expansion %s | Enemy nests: %d to %d | Result: %s | Next attempt: %s.",
      surface.name,
      succeeded and "succeeded" or "failed",
      before,
      after,
      value.last_attempt_result,
      remaining_text(value)
    ))
  end
end

local function run_attack_test(command)
  local targets = main_locomotives()
  if #targets == 0 then
    command_print(command, "[Train Interiors] Main Locomotive attack target is unavailable on Nauvis.")
    return
  end
  for _, target in ipairs(targets) do
    local value = attack_state_for(target)
    local before = train_interiors.interior_pollution.attack_budget(target)
    local succeeded, sent, result = dispatch_train_attack(target, value)
    local after = train_interiors.interior_pollution.attack_budget(target)
    command_print(command, string.format(
      "[Train Interiors] Main Locomotive #%d: Immediate attack %s | Sent: %d | Train pollution: %.1f to %.1f | Result: %s | Next attack: %s.",
      target.unit_number,
      succeeded and "succeeded" or "failed",
      sent,
      before,
      after,
      result,
      attack_remaining_text(value)
    ))
  end
end

local function test_command(command)
  local player = command.player_index and game.get_player(command.player_index) or nil
  if player and not player.admin then
    player.print("Only an administrator can use the enemy-expansion test command.")
    return
  end
  local surfaces = main_surfaces()
  if #surfaces == 0 then
    command_print(command, "[Train Interiors] No active Nauvis surface was found.")
    return
  end

  local parameter = (command.parameter or "status"):match("^%s*(.-)%s*$")
  local lower_parameter = parameter:lower()
  if parameter == "" or lower_parameter == "status" then
    test_status(command, surfaces)
    return
  end
  if lower_parameter == "now" then
    run_immediate_test(command, surfaces)
    return
  end
  if lower_parameter == "attack" then
    run_attack_test(command)
    return
  end

  local percent = tonumber(parameter)
  if not percent or percent < 0 or percent > 100 then
    command_print(command, "Usage: /the-cave-expansion-test <0-100|now|attack|status>")
    return
  end

  for _, surface in ipairs(surfaces) do
    game.forces.enemy.set_evolution_factor(percent / 100, surface)
    local value = state_for(surface)
    schedule_next(surface, value, game.tick, true)
    command_print(command, string.format(
      "[Train Interiors] %s: Evolution set to %.1f%% | Fresh Expansion timer: %d seconds | Enemy nests: %d.",
      surface.name,
      percent,
      math.ceil((value.next_tick - game.tick) / 60),
      surface.count_entities_filtered {type = "unit-spawner", force = "enemy"}
    ))
  end
  if not expansion_enabled() then
    command_print(command, "[Train Interiors] Allow Biter Expansion is currently disabled.")
  end
end

function M.register_commands()
  commands.add_command(
    "the-cave-expansion-test",
    "Admin test: build one nest, attack the Main Locomotive, set Evolution, or show status.",
    test_command
  )
end

function M.on_init()
  root()
  apply_map_settings()
  apply_attack_pollution_cost()
end

function M.on_configuration_changed()
  local value = root()
  for surface_index in pairs(value.surfaces) do
    local surface = game.surfaces[surface_index]
    if not (surface and surface.valid) then value.surfaces[surface_index] = nil end
  end
  apply_map_settings()
  apply_attack_pollution_cost()
  if not setting_enabled() then
    value.surfaces = {}
    value.attack_targets = {}
    train_interiors.interior_pollution.clear_attack_budgets()
  end
end

function M.on_nth_tick(event)
  if not (event and event.tick and event.tick % CHECK_INTERVAL == 0) then return end
  local expansion = game.map_settings and game.map_settings.enemy_expansion
  if not setting_enabled() or not (expansion and expansion.enabled) then return end

  for _, surface in pairs(main_surfaces()) do
    local value = state_for(surface)
    if not value.next_tick then
      schedule_next(surface, value, event.tick, true)
    elseif event.tick >= value.next_tick then
      value.sequence = value.sequence + 1
      local succeeded = attempt_expansion(surface, value)
      schedule_next(surface, value, event.tick, succeeded)
    end
  end

  local targets = main_locomotives()
  prune_attack_states(targets)
  for _, target in ipairs(targets) do
    local value = attack_state_for(target)
    if not value.next_tick then
      value.next_tick = event.tick + TRAIN_ATTACK_COOLDOWN
    elseif event.tick >= value.next_tick then
      dispatch_train_attack(target, value)
    end
  end
end

function M.on_surface_deleted(event)
  if event and event.surface_index then root().surfaces[event.surface_index] = nil end
end

return M
