local settings = require("scripts.game_settings").proxy(settings)

-- Train Interiors Ore Blood mode.
-- Optional startup reward layer: killed vanilla and Armoured Biters/Spitters drop
-- one random basic resource bundle. Coin drops are intentionally unchanged.
-- Worms, nests/spawners, pentapods, demolishers, turrets, and other enemies are
-- not affected.

local ore_blood = {}

local BASIC_RESOURCES = { "iron-ore", "copper-ore", "coal", "stone" }

local UNIT_DROPS = {
    -- Increased after player testing: the first pass was too tiny to feel useful.
    ["small-biter"] = { min = 10, max = 20 },
    ["small-spitter"] = { min = 10, max = 20 },

    ["medium-biter"] = { min = 20, max = 40 },
    ["medium-spitter"] = { min = 20, max = 40 },

    ["big-biter"] = { min = 40, max = 80 },
    ["big-spitter"] = { min = 40, max = 80 },

    ["behemoth-biter"] = { min = 80, max = 160 },
    ["behemoth-spitter"] = { min = 80, max = 160 },

    ["small-armoured-biter"] = { min = 10, max = 20 },
    ["medium-armoured-biter"] = { min = 20, max = 40 },
    ["big-armoured-biter"] = { min = 40, max = 80 },
    ["behemoth-armoured-biter"] = { min = 80, max = 160 },
    ["leviathan-armoured-biter"] = { min = 160, max = 320 },
}

local BASIC_RESOURCE_SET = {}
for _, resource_name in pairs(BASIC_RESOURCES) do
    BASIC_RESOURCE_SET[resource_name] = true
end

local function setting_enabled()
    local setting = settings and settings.startup and settings.startup["the-cave-ore-blood"]
    return not setting or setting.value == "enabled" or setting.value == true
end

local function item_exists(name)
    if prototypes and prototypes.item and prototypes.item[name] then return true end

    local ok, items = pcall(function()
        return game.item_prototypes
    end)
    return ok and items and items[name] ~= nil
end

local function random_basic_resource()
    return BASIC_RESOURCES[math.random(1, #BASIC_RESOURCES)] or "iron-ore"
end

function ore_blood.enabled()
    return setting_enabled()
end

local function get_pickup_position(player)
    if not player or not player.valid then return nil end
    if player.character and player.character.valid then
        return player.character.position
    end
    if player.vehicle and player.vehicle.valid then
        return player.vehicle.position
    end
    return player.position
end

local function try_pickup_resource(player, item_entity)
    if not player or not player.valid or not item_entity or not item_entity.valid then return end
    local stack = item_entity.stack
    if not stack or not stack.valid_for_read or not BASIC_RESOURCE_SET[stack.name] then return end

    local name = stack.name
    local count = stack.count
    if count <= 0 then
        item_entity.destroy()
        return
    end

    local inserted = player.insert { name = name, count = count }
    if inserted <= 0 then return end

    if inserted >= count then
        item_entity.destroy()
    else
        stack.count = count - inserted
    end
end

function ore_blood.auto_pickup_resources()
    if not setting_enabled() then return end

    for _, player in pairs(game.connected_players) do
        if player and player.valid and player.controller_type ~= defines.controllers.spectator then
            local surface = player.surface
            local position = get_pickup_position(player)
            if surface and surface.valid and position then
                local radius = 1.15
                local items = surface.find_entities_filtered {
                    name = "item-on-ground",
                    area = {
                        { position.x - radius, position.y - radius },
                        { position.x + radius, position.y + radius }
                    }
                }

                for _, item_entity in pairs(items) do
                    try_pickup_resource(player, item_entity)
                end
            end
        end
    end
end

function ore_blood.on_entity_died(event)
    local entity = event and event.entity
    if not entity or not entity.valid then return end
    if not setting_enabled() then return end
    local range = UNIT_DROPS[entity.name]
    if not range then return end
    local count = math.random(range.min, range.max)

    local surface = entity.surface
    if not surface or not surface.valid then return end

    local resource = random_basic_resource()
    if not item_exists(resource) then return end
    if not count or count <= 0 then return end

    -- Split larger rewards into valid ground stacks so resource stack-size
    -- settings cannot silently cap or delete part of a reward.
    local prototype = prototypes and prototypes.item and prototypes.item[resource]
    local stack_size = math.max(1, math.floor(tonumber(prototype and prototype.stack_size) or count))
    local remaining = count
    while remaining > 0 do
        local stack_count = math.min(remaining, stack_size)
        local created = nil
        local ok = pcall(function()
            created = surface.create_entity {
                name = "item-on-ground",
                position = entity.position,
                stack = { name = resource, count = stack_count }
            }
        end)
        if not ok or not created then break end
        remaining = remaining - stack_count
    end
end

return ore_blood
