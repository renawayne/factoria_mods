-- Train Interiors exterior lighting modes.
local M = {}

local TRAIN_SURFACE_PREFIX = "the-cave-train-interior-"
local SOLAR_DAY = 1
local SOLAR_NIGHT = 10
local SOLAR_PITCH_BLACK = 5

local function mode()
  local setting = settings.startup["the-cave-underground-lighting-mode"]
  return setting and setting.value or "permanent-night"
end

local function train_surface(surface)
  return surface.name:sub(1, #TRAIN_SURFACE_PREFIX) == TRAIN_SURFACE_PREFIX
end

local function apply(surface)
  if not (surface and surface.valid) then return end
  if train_surface(surface) then
    pcall(function() surface.always_day = true end)
    pcall(function() surface.freeze_daytime = true end)
    pcall(function() surface.daytime = 0.1 end)
    pcall(function() surface.min_brightness = 0.15 end)
    pcall(function() surface.solar_power_multiplier = 1 end)
    return
  end
  if surface.name ~= "nauvis" then return end

  local selected = mode()
  if selected == "normal" then
    pcall(function() surface.always_day = false end)
    pcall(function() surface.freeze_daytime = false end)
    pcall(function() surface.solar_power_multiplier = 1 end)
    pcall(function() surface.dusk = 0.25 end)
    pcall(function() surface.evening = 0.45 end)
    pcall(function() surface.morning = 0.55 end)
    pcall(function() surface.dawn = 0.75 end)
    pcall(function() surface.show_clouds = true end)
    pcall(function() surface.min_brightness = 0.15 end)
  elseif selected == "permanent-day" then
    pcall(function() surface.always_day = true end)
    pcall(function() surface.freeze_daytime = false end)
    pcall(function() surface.daytime = 0 end)
    pcall(function() surface.solar_power_multiplier = SOLAR_DAY end)
    pcall(function() surface.show_clouds = true end)
    pcall(function() surface.min_brightness = 0.15 end)
  elseif selected == "pitch-black" then
    pcall(function() surface.always_day = false end)
    pcall(function() surface.freeze_daytime = true end)
    pcall(function() surface.daytime = 0.44 end)
    pcall(function() surface.dusk = 0.25 end)
    pcall(function() surface.evening = 0.45 end)
    pcall(function() surface.morning = 0.55 end)
    pcall(function() surface.dawn = 0.75 end)
    pcall(function() surface.show_clouds = false end)
    pcall(function() surface.brightness_visual_weights = {r = 1, g = 1, b = 1} end)
    pcall(function() surface.min_brightness = 0 end)
    pcall(function() surface.solar_power_multiplier = SOLAR_PITCH_BLACK end)
  else
    pcall(function() surface.always_day = false end)
    pcall(function() surface.freeze_daytime = true end)
    pcall(function() surface.daytime = 0.44 end)
    pcall(function() surface.dusk = 0.25 end)
    pcall(function() surface.evening = 0.45 end)
    pcall(function() surface.morning = 0.55 end)
    pcall(function() surface.dawn = 0.75 end)
    pcall(function() surface.show_clouds = false end)
    pcall(function() surface.min_brightness = 0 end)
    pcall(function() surface.solar_power_multiplier = SOLAR_NIGHT end)
  end
end

function M.apply_all()
  for _, surface in pairs(game.surfaces) do apply(surface) end
end

function M.on_init() M.apply_all() end
function M.on_configuration_changed() M.apply_all() end
function M.on_tick(event)
  if event.tick % 60 == 0 then M.apply_all() end
end

return M

