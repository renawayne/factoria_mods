-- Standalone player-centred darkness threat.
local M = {}

local CHECK_INTERVAL = 240
local GRACE_TICKS = 30 * 60
local SMALL_LAMP_RANGE = 12
local LAMP_POST_RANGE = 30
local SAFE_CHUNK_RADIUS = 2
local MAX_WAVE_SIZE = 20
local TRAIN_SURFACE_PREFIX = "the-cave-train-interior-"
local LIGHTING_SETTING_NAME = "the-cave-underground-lighting-mode"

local function enabled()
  local setting = settings.startup["the-cave-darkness-infestation"]
  return not setting or setting.value == "enabled"
end

local function lighting_mode()
  local setting = settings.startup[LIGHTING_SETTING_NAME]
  return setting and setting.value or "permanent-night"
end

local function normal_mode_is_night(surface)
  if not (surface and surface.valid) then return false end
  local daytime = tonumber(surface.daytime) or 0
  local evening = tonumber(surface.evening) or 0.45
  local morning = tonumber(surface.morning) or 0.55
  if evening <= morning then
    return daytime >= evening and daytime < morning
  end
  return daytime >= evening or daytime < morning
end

local function infestation_active(surface)
  if not enabled() then return false end
  local selected = lighting_mode()
  if selected == "permanent-day" then return false end
  if selected == "normal" then return normal_mode_is_night(surface) end
  return selected == "permanent-night" or selected == "pitch-black"
end

local function state()
  storage.train_interiors_darkness = storage.train_interiors_darkness or {players = {}}
  storage.train_interiors_darkness.players =
    storage.train_interiors_darkness.players or {}
  return storage.train_interiors_darkness
end

local function reset(record)
  record.unlit_since = nil
  record.last_spawn_tick = nil
  record.threat = 0
end

local function prune_spawned_units(record)
  local kept = {}
  for _, unit in pairs(record.spawned_units or {}) do
    if unit and unit.valid then kept[#kept + 1] = unit end
  end
  record.spawned_units = kept
end

local function remove_spawned_units(record)
  for _, unit in pairs(record.spawned_units or {}) do
    if unit and unit.valid then pcall(function() unit.destroy() end) end
  end
  record.spawned_units = {}
end

local function deactivate(record)
  record.in_darkness_zone = false
  remove_spawned_units(record)
  reset(record)
end

local function deactivate_all()
  local root = storage.train_interiors_darkness
  if not (root and root.players) then return end
  for _, record in pairs(root.players) do deactivate(record) end
end

local function is_train_surface(surface)
  return surface and surface.valid
    and surface.name:sub(1, #TRAIN_SURFACE_PREFIX) == TRAIN_SURFACE_PREFIX
end

local function is_nauvis(surface)
  return surface and surface.valid and surface.name == "nauvis"
end

local function in_safe_zone(player, surface, position)
  local spawn = player.force.get_spawn_position(surface)
  return math.abs(math.floor(position.x / 32) - math.floor(spawn.x / 32)) <= SAFE_CHUNK_RADIUS
    and math.abs(math.floor(position.y / 32) - math.floor(spawn.y / 32)) <= SAFE_CHUNK_RADIUS
end

local function powered_lamp(player, surface, position, name, range)
  for _, lamp in pairs(surface.find_entities_filtered {
    area = {
      {position.x - range, position.y - range},
      {position.x + range, position.y + range},
    },
    name = name,
    force = player.force,
  }) do
    if lamp.valid and lamp.energy > 0 then
      local behavior = lamp.get_or_create_control_behavior()
      if not behavior or not behavior.disabled then return true end
    end
  end
  return false
end

local function has_light(player, surface, position)
  if powered_lamp(player, surface, position, "small-lamp", SMALL_LAMP_RANGE) then
    return true
  end
  if prototypes.entity["lamp-post"] then
    return powered_lamp(player, surface, position, "lamp-post", LAMP_POST_RANGE)
  end
  return false
end

local function evolution(surface)
  local enemy = game.forces.enemy
  local value = 0
  if enemy and enemy.valid then
    local ok, result = pcall(function() return enemy.get_evolution_factor(surface) end)
    if ok and type(result) == "number" then value = result
    else value = tonumber(enemy.evolution_factor) or 0 end
  end
  return math.max(0, math.min(1, value))
end

local function enemy_names(surface)
  local value = evolution(surface)
  if value >= 0.85 then return "behemoth-biter", "behemoth-spitter" end
  if value >= 0.55 then return "big-biter", "big-spitter" end
  if value >= 0.25 then return "medium-biter", "medium-spitter" end
  return "small-biter", "small-spitter"
end

local function spawn_enemy(character, surface, origin, index)
  local biter, spitter = enemy_names(surface)
  local name = math.random() < 0.70 and biter or spitter
  local angle = index * 2.399963229728653 + math.random()
  local distance = 7 + math.random() * 5
  local candidate = {
    x = origin.x + math.cos(angle) * distance,
    y = origin.y + math.sin(angle) * distance,
  }
  local position = surface.find_non_colliding_position(name, candidate, 6, 0.5)
  if not position then return nil end
  local unit = surface.create_entity {name = name, position = position, force = "enemy"}
  if not (unit and unit.valid and unit.commandable and character.valid) then
    if unit and unit.valid then unit.destroy() end
    return nil
  end
  local ok = pcall(function()
    unit.commandable.set_command {
      type = defines.command.attack,
      target = character,
      distraction = defines.distraction.none,
    }
  end)
  if not ok and unit.valid then unit.destroy() end
  if not ok then return nil end
  return unit
end

local function warn(player)
  player.print({"the-cave-darkness.entered-zone"})
  pcall(function() player.play_sound {path = "utility/console_message"} end)
end

function M.on_init()
  state()
end

function M.on_configuration_changed()
  if enabled() then
    state()
    local nauvis = game and game.surfaces and game.surfaces["nauvis"] or nil
    if not infestation_active(nauvis) then deactivate_all() end
  else
    deactivate_all()
    storage.train_interiors_darkness = nil
  end
end

function M.on_player_removed(event)
  local root = storage.train_interiors_darkness
  if root and root.players then
    local record = root.players[event.player_index]
    if record then remove_spawned_units(record) end
    root.players[event.player_index] = nil
  end
end

function M.on_player_changed_surface(event)
  if not enabled() then return end
  local record = state().players[event.player_index]
  if record then
    record.surface_index = nil
    deactivate(record)
  end
end

function M.on_nth_tick(event)
  if not enabled() then
    deactivate_all()
    return
  end
  local nauvis = game and game.surfaces and game.surfaces["nauvis"] or nil
  if not infestation_active(nauvis) then
    deactivate_all()
    return
  end
  local root = state()
  for _, player in pairs(game.connected_players) do
    local record = root.players[player.index] or {threat = 0, spawned_units = {}}
    root.players[player.index] = record
    prune_spawned_units(record)
    local character = player.character
    local surface = character and character.valid and character.surface or nil
    local position = character and character.valid and character.position or nil

    if not infestation_active(surface) then
      deactivate(record)
    elseif not (character and surface and position)
      or is_train_surface(surface)
      or not is_nauvis(surface)
      or in_safe_zone(player, surface, position) then
      record.in_darkness_zone = false
      reset(record)
    else
      if not record.in_darkness_zone then
        record.in_darkness_zone = true
        warn(player)
      end
      if character.driving or has_light(player, surface, position) then
        reset(record)
      else
        record.unlit_since = record.unlit_since or event.tick
        if event.tick - record.unlit_since >= GRACE_TICKS
          and (not record.last_spawn_tick
            or event.tick - record.last_spawn_tick >= CHECK_INTERVAL) then
          local elapsed = math.floor((event.tick - record.unlit_since) / CHECK_INTERVAL)
          record.threat = elapsed
          local wanted = math.min(2 + elapsed, MAX_WAVE_SIZE)
          for index = 1, wanted do
            local unit = spawn_enemy(character, surface, position, index)
            if unit then record.spawned_units[#record.spawned_units + 1] = unit end
          end
          record.last_spawn_tick = event.tick
        end
      end
    end
    record.surface_index = surface and surface.index or nil
  end
end

return M
