-- Train Interiors: standalone data stage.

data:extend({
  {
    type = "sprite",
    name = "the-cave-locomotive-garden-portal",
    filename = "__train-interiors__/graphics/train_interiors/locomotive-garden-portal.png",
    width = 256,
    height = 256,
    scale = 0.25,
    priority = "extra-high"
  },
  {
    type = "custom-input",
    name = "the-cave-enter-train-interior",
    key_sequence = "CONTROL + ENTER",
    consuming = "game-only",
    order = "train-interiors-enter"
  },
  {
    type = "shortcut",
    name = "the-cave-enter-train-interior-shortcut",
    action = "lua",
    associated_control_input = "the-cave-enter-train-interior",
    order = "z[train-interiors]-a[enter]",
    localised_name = {"shortcut-name.the-cave-enter-train-interior-shortcut"},
    localised_description = {"shortcut-description.the-cave-enter-train-interior-shortcut"},
    icon = "__base__/graphics/icons/locomotive.png",
    icon_size = 64,
    small_icon = "__base__/graphics/icons/locomotive.png",
    small_icon_size = 64
  }
})

require("prototypes.train_hidden_radar")
require("prototypes.train_power_bridge")
require("prototypes.train_transfer_containers")
require("prototypes.train_fluid_transfer_tank")
require("prototypes.train_garden_transfer")
require("prototypes.resource_eraser")
require("prototypes.electric_furnaces")
local lamp_post_setting = settings.startup["the-cave-lamp-post"]
if not lamp_post_setting or lamp_post_setting.value == "enabled" then
  require("prototypes.lamp_post")
end
require("prototypes.technology")

-- Integrated Damage Indicator font.
data:extend({
  {
    type = "font",
    name = "damage-indicator-font",
    from = "default-bold",
    size = 16,
    border = true,
    border_color = {0, 0, 0, 1}
  },
  {
    type = "equipment-grid",
    name = "train-interiors-locomotive-grid",
    width = 10,
    height = 8,
    equipment_categories = {"armor", "vehicle"}
  }
})

-- Mod-owned rolling stock is used only for the Starter Train and abandoned
-- world finds. The high physical ceiling is required by the shared 5,000-
-- 35,000 HP Train Shield: runtime maps the shared pool ratio onto this ceiling.
-- Vanilla rolling-stock prototype health remains untouched. Its recipes are
-- disabled separately because Main Train parts must be found through exploration.
local SHIELD_PHYSICAL_HEALTH_CEILING = 35000
local protected_stock = {
  {type = "locomotive", base = "locomotive", name = "train-interiors-locomotive", equipment_grid = "train-interiors-locomotive-grid"},
  {type = "cargo-wagon", base = "cargo-wagon", name = "train-interiors-cargo-wagon", inventory_size = 80, equipment_grid = "train-interiors-locomotive-grid"},
  {type = "fluid-wagon", base = "fluid-wagon", name = "train-interiors-fluid-wagon", equipment_grid = "train-interiors-locomotive-grid"},
  {type = "artillery-wagon", base = "artillery-wagon", name = "train-interiors-artillery-wagon", equipment_grid = "train-interiors-locomotive-grid"},
}

for _, definition in ipairs(protected_stock) do
  local group = data.raw[definition.type]
  local base = group and group[definition.base]
  if base and not group[definition.name] then
    local entity = table.deepcopy(base)
    entity.name = definition.name
    entity.localised_name = {"entity-name." .. definition.name}
    entity.localised_description = {"entity-description." .. definition.name}
    if definition.inventory_size then entity.inventory_size = definition.inventory_size end
    
    -- 3. Добавляем присвоение сетки, если она указана в определении
    if definition.equipment_grid then 
      entity.equipment_grid = definition.equipment_grid 
    end
    
    entity.max_health = SHIELD_PHYSICAL_HEALTH_CEILING
    entity.repair_speed_modifier = 0
    entity.healing_per_tick = 0
    entity.minable = nil
    entity.hidden = true
    entity.hidden_in_factoriopedia = true
    entity.flags = table.deepcopy(base.flags or {})
    local seen_flags = {}
    for _, flag in pairs(entity.flags) do seen_flags[flag] = true end
    for _, flag in ipairs({"not-blueprintable", "not-deconstructable", "not-repairable"}) do
      if not seen_flags[flag] then entity.flags[#entity.flags + 1] = flag end
    end
    data:extend({entity})
  end
end
