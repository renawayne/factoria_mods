local train_interiors = require("scripts.train_interiors")
local starter_pack = require("scripts.starter_pack")
local minimal_wire = require("scripts.minimal_wire")
local inventory_repair = require("scripts.inventory_repair")
local damage_indicator = require("scripts.damage_indicator.main")
local darkness_infestation = require("scripts.darkness_infestation")
local ore_blood = require("scripts.ore_blood")
local resource_eraser = require("scripts.resource_eraser")
local lighting = require("scripts.lighting")
local enemy_expansion = require("scripts.enemy_expansion")
local everything_on_nauvis = require("scripts.everything_on_nauvis_progression")
local everything_on_nauvis_regions = require("scripts.everything_on_nauvis_regions")
local fulgora_lightning = require("scripts.fulgora_lightning")

enemy_expansion.register_commands()

local function startup_enabled(name, default_enabled)
  local setting = settings and settings.startup and settings.startup[name]
  if not setting then return default_enabled ~= false end
  return setting.value == "enabled" or setting.value == true
end

local function damage_indicator_enabled()
  return startup_enabled("the-cave-integrated-damage-indicator", true)
end

local function initialize_existing_forces()
  for _, player in pairs(game.players or {}) do
    train_interiors.spawn_starter_train_for_player(player)
  end
end

script.on_init(function()
  train_interiors.on_init()
  starter_pack.on_init()
  minimal_wire.on_init()
  inventory_repair.on_init()
  if damage_indicator_enabled() then damage_indicator.on_init() end
  darkness_infestation.on_init()
  lighting.on_init()
  enemy_expansion.on_init()
  everything_on_nauvis.on_init()
  everything_on_nauvis_regions.on_init()
  initialize_existing_forces()
end)

script.on_load(function()
  if damage_indicator_enabled() then damage_indicator.on_load() end
end)

script.on_configuration_changed(function()
  train_interiors.on_configuration_changed()
  starter_pack.on_configuration_changed()
  minimal_wire.on_configuration_changed()
  inventory_repair.on_configuration_changed()
  if damage_indicator_enabled() then
    damage_indicator.on_configuration_changed()
  else
    damage_indicator.cleanup_legacy_shared_state()
  end
  darkness_infestation.on_configuration_changed()
  lighting.on_configuration_changed()
  enemy_expansion.on_configuration_changed()
  everything_on_nauvis.on_configuration_changed()
  everything_on_nauvis_regions.on_configuration_changed()
  initialize_existing_forces()
end)

script.on_event(defines.events.on_player_created, function(event)
  train_interiors.on_player_created(event)
  starter_pack.on_player_created(event)
  inventory_repair.on_player_created(event)
  everything_on_nauvis.on_player_created(event)
end)

script.on_event(defines.events.on_player_joined_game, function(event)
  train_interiors.on_player_joined_game(event)
  starter_pack.on_player_joined_game(event)
  inventory_repair.on_player_joined_game(event)
  if damage_indicator_enabled() then damage_indicator.on_player_joined_game(event) end
end)

script.on_event(defines.events.on_player_left_game, function(event)
  train_interiors.on_player_left_game(event)
  inventory_repair.on_player_left_game(event)
  if damage_indicator_enabled() then damage_indicator.on_player_left_game(event) end
end)

if defines.events.on_player_removed then
  script.on_event(defines.events.on_player_removed, function(event)
    darkness_infestation.on_player_removed(event)
    if damage_indicator_enabled() then damage_indicator.on_player_removed(event) end
  end)
end

script.on_event(defines.events.on_player_changed_position, function(event)
  train_interiors.on_player_changed_position(event)
  if damage_indicator_enabled() then damage_indicator.on_player_changed_position(event) end
end)

script.on_event(defines.events.on_player_changed_surface, function(event)
  train_interiors.on_player_changed_surface(event)
  darkness_infestation.on_player_changed_surface(event)
end)

script.on_event(defines.events.on_player_respawned, train_interiors.on_player_respawned)
script.on_event(defines.events.on_player_driving_changed_state, train_interiors.on_player_driving_changed_state)

if defines.events.on_force_created then
  script.on_event(defines.events.on_force_created, function(event)
    train_interiors.on_force_created(event)
    everything_on_nauvis.on_force_created(event)
  end)
end

if defines.events.on_player_changed_force then
  script.on_event(defines.events.on_player_changed_force, function(event)
    train_interiors.lock_all_train_recipes()
    everything_on_nauvis.on_player_changed_force(event)
  end)
end

local progression_reset_events = {}
for _, event_id in pairs({
  defines.events.on_force_reset,
  defines.events.on_technology_effects_reset,
  defines.events.on_forces_merged,
}) do
  if event_id then progression_reset_events[#progression_reset_events + 1] = event_id end
end
if #progression_reset_events > 0 then
  script.on_event(progression_reset_events, function()
    train_interiors.lock_all_train_recipes()
    everything_on_nauvis.on_configuration_changed()
  end)
end

if defines.events.on_train_created then
  script.on_event(defines.events.on_train_created, train_interiors.on_train_created)
end

local function on_built(event)
  train_interiors.on_built(event)
  local entity = event.entity or event.created_entity
  if not (entity and entity.valid) then return end
  if entity.valid then minimal_wire.on_built(entity) end
end

local built_events = {
  defines.events.on_built_entity,
  defines.events.on_robot_built_entity,
  defines.events.script_raised_built,
  defines.events.script_raised_revive,
}
if defines.events.on_space_platform_built_entity then
  built_events[#built_events + 1] = defines.events.on_space_platform_built_entity
end
script.on_event(built_events, on_built)

script.on_event(defines.events.on_pre_player_mined_item, function(event)
  minimal_wire.on_pre_removed(event.entity)
  train_interiors.on_entity_removed(event.entity)
  if damage_indicator_enabled() then damage_indicator.on_entity_gone(event) end
end)

script.on_event(defines.events.on_robot_pre_mined, function(event)
  minimal_wire.on_pre_removed(event.entity)
  train_interiors.on_entity_removed(event.entity)
  if damage_indicator_enabled() then damage_indicator.on_entity_gone(event) end
end)

local gleba_nest_mined_events = {}
if defines.events.on_player_mined_entity then
  gleba_nest_mined_events[#gleba_nest_mined_events + 1] = defines.events.on_player_mined_entity
end
if defines.events.on_robot_mined_entity then
  gleba_nest_mined_events[#gleba_nest_mined_events + 1] = defines.events.on_robot_mined_entity
end
if #gleba_nest_mined_events > 0 then
  script.on_event(gleba_nest_mined_events, function(event)
    everything_on_nauvis_regions.on_gleba_nest_removed(event.entity, event.buffer)
  end)
end

script.on_event(defines.events.script_raised_destroy, function(event)
  if event.entity then
    minimal_wire.on_removed(event.entity)
    train_interiors.on_entity_removed(event.entity)
  end
  if damage_indicator_enabled() then damage_indicator.on_entity_gone(event) end
end)

script.on_event(defines.events.on_entity_died, function(event)
  if event.entity then minimal_wire.on_removed(event.entity) end
  everything_on_nauvis_regions.on_gleba_nest_removed(event.entity, event.buffer)
  ore_blood.on_entity_died(event)
  train_interiors.on_entity_died(event)
  if damage_indicator_enabled() then damage_indicator.on_entity_gone(event) end
end)

script.on_event(defines.events.on_entity_damaged, function(event)
  train_interiors.on_entity_damaged(event)
  if damage_indicator_enabled() then damage_indicator.on_entity_damaged(event) end
end, {
  {filter = "final-damage-amount", comparison = ">", value = 0},
})

if defines.events.on_script_trigger_effect then
  script.on_event(defines.events.on_script_trigger_effect, function(event)
    if damage_indicator_enabled() then damage_indicator.on_script_trigger_effect(event) end
  end)
end

script.on_event(defines.events.on_gui_click, function(event)
  train_interiors.on_gui_click(event)
  if damage_indicator_enabled() then damage_indicator.on_gui_click(event) end
end)

script.on_event(defines.events.on_gui_closed, function(event)
  if damage_indicator_enabled() then damage_indicator.on_gui_closed(event) end
end)

script.on_event(defines.events.on_selected_entity_changed, train_interiors.on_selected_entity_changed)
script.on_event(defines.events.on_research_finished, train_interiors.on_research_finished)
script.on_event(defines.events.on_chunk_generated, function(event)
  everything_on_nauvis_regions.on_chunk_generated(event)
  train_interiors.on_chunk_generated(event)
end)
script.on_event(defines.events.on_chunk_charted, train_interiors.on_chunk_charted)

local function tiles_changed(event)
  local surface = event.surface_index and game.surfaces[event.surface_index]
    or (event.robot and event.robot.valid and event.robot.surface)
  if surface then train_interiors.on_tiles_changed(surface, event.tiles or {}) end
end

local tile_events = {
  defines.events.on_player_built_tile,
  defines.events.on_robot_built_tile,
  defines.events.on_player_mined_tile,
  defines.events.on_robot_mined_tile,
}
if defines.events.script_raised_set_tiles then
  tile_events[#tile_events + 1] = defines.events.script_raised_set_tiles
end
script.on_event(tile_events, tiles_changed)

script.on_event(defines.events.on_player_selected_area, resource_eraser.on_player_selected_area)
if defines.events.on_player_alt_selected_area then
  script.on_event(defines.events.on_player_alt_selected_area, resource_eraser.on_player_alt_selected_area)
end

if defines.events.on_player_main_inventory_changed then
  script.on_event(defines.events.on_player_main_inventory_changed,
    inventory_repair.on_player_main_inventory_changed)
end

script.on_event(defines.events.on_runtime_mod_setting_changed, function(event)
  minimal_wire.on_runtime_mod_setting_changed(event)
  inventory_repair.on_runtime_mod_setting_changed(event)
  if damage_indicator_enabled() then damage_indicator.on_runtime_mod_setting_changed(event) end
end)

if defines.events.on_surface_created then
  script.on_event(defines.events.on_surface_created, function() lighting.apply_all() end)
end

script.on_event("the-cave-enter-train-interior", train_interiors.on_enter_interior_hotkey)
script.on_event(defines.events.on_lua_shortcut, train_interiors.on_lua_shortcut)

script.on_nth_tick(240, darkness_infestation.on_nth_tick)
script.on_nth_tick(300, enemy_expansion.on_nth_tick)
script.on_nth_tick(30, fulgora_lightning.sync_warning_icons)
script.on_nth_tick(120, fulgora_lightning.on_nth_tick)

if defines.events.on_surface_deleted then
  script.on_event(defines.events.on_surface_deleted, enemy_expansion.on_surface_deleted)
end

script.on_event(defines.events.on_tick, function(event)
  minimal_wire.on_tick(event)
  if event.tick % 5 == 0 then ore_blood.auto_pickup_resources() end
  train_interiors.on_tick(event)
  inventory_repair.on_tick(event)
  if damage_indicator_enabled() then damage_indicator.on_tick(event) end
  lighting.on_tick(event)
end)
